import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/theme/vibe_theme.dart';
import 'providers/match_provider.dart';
import 'providers/session_provider.dart';
import 'providers/social_provider.dart';
import 'providers/wallet_provider.dart';
import 'screens/home/home_shell.dart';
import 'screens/onboarding/permissions_screen.dart';
import 'screens/onboarding/profile_setup_screen.dart';
import 'screens/onboarding/signin_screen.dart';
import 'screens/onboarding/welcome_screen.dart';
import 'screens/splash_screen.dart';

class VibeApp extends StatefulWidget {
  const VibeApp({super.key});

  @override
  State<VibeApp> createState() => _VibeAppState();
}

class _VibeAppState extends State<VibeApp> {
  bool _sawWelcome = false;

  @override
  void initState() {
    super.initState();
    // Restore everything once; the splash shows meanwhile.
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final session = context.read<SessionProvider>();
      await session.restore();
      await context.read<WalletProvider>().load();
      await context.read<SocialProvider>().load();
      await context.read<MatchProvider>().load();
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vibe',
      debugShowCheckedModeBanner: false,
      theme: V.theme(),
      home: Consumer<SessionProvider>(
        builder: (context, session, _) {
          if (session.booting) return const SplashScreen();
          if (!session.signedIn) {
            if (!_sawWelcome) return WelcomeScreen(onContinue: () => setState(() => _sawWelcome = true));
            return const SignInScreen();
          }
          if (!session.profileReady) return const ProfileSetupScreen();
          if (!session.onboarded) return const PermissionsScreen();
          return const HomeShell();
        },
      ),
    );
  }
}
