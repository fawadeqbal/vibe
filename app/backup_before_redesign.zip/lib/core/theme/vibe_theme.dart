import 'package:flutter/material.dart';

/// Vibe's visual world: near-black ground, one hot accent that runs
/// pink → violet, gold for coins, teal for gems. Built for a phone held in
/// the dark at 11pm; every surface is a step lighter than the one under it,
/// never a border for its own sake.
class V {
  V._();

  static const Color bg = Color(0xFF0B0A10);
  static const Color bg2 = Color(0xFF12101A);
  static const Color surface = Color(0xFF1A1724);
  static const Color surface2 = Color(0xFF241F31);
  static const Color surface3 = Color(0xFF2E2840);
  static const Color line = Color(0x14FFFFFF);
  static const Color lineStrong = Color(0x24FFFFFF);

  static const Color text = Color(0xFFF4F1FA);
  static const Color text2 = Color(0xFFB9B3C9);
  static const Color muted = Color(0xFF7F7893);

  static const Color pink = Color(0xFFFF3D8F);
  static const Color violet = Color(0xFF8B5CF6);
  static const Color pinkDeep = Color(0xFFD62E76);
  static const Color gold = Color(0xFFFFC857);
  static const Color gem = Color(0xFF5EEAD4);
  static const Color ok = Color(0xFF34D399);
  static const Color bad = Color(0xFFFB7185);
  static const Color warn = Color(0xFFFBBF24);

  static const LinearGradient brand = LinearGradient(colors: [pink, violet], begin: Alignment.topLeft, end: Alignment.bottomRight);
  static const LinearGradient brandSoft = LinearGradient(colors: [Color(0x33FF3D8F), Color(0x338B5CF6)], begin: Alignment.topLeft, end: Alignment.bottomRight);
  static const LinearGradient goldGrad = LinearGradient(colors: [Color(0xFFFFD98A), Color(0xFFF0A020)], begin: Alignment.topLeft, end: Alignment.bottomRight);
  static const LinearGradient gemGrad = LinearGradient(colors: [Color(0xFF8CF5E4), Color(0xFF2DD4BF)], begin: Alignment.topLeft, end: Alignment.bottomRight);

  static const double r = 18;
  static const double rSm = 12;
  static const double rLg = 28;

  static ThemeData theme() {
    const scheme = ColorScheme(
      brightness: Brightness.dark,
      primary: pink,
      onPrimary: Colors.white,
      secondary: violet,
      onSecondary: Colors.white,
      error: bad,
      onError: Colors.black,
      surface: surface,
      onSurface: text,
    );
    final base = ThemeData(useMaterial3: true, colorScheme: scheme, scaffoldBackgroundColor: bg);
    return base.copyWith(
      textTheme: base.textTheme.apply(bodyColor: text, displayColor: text),
      splashFactory: InkSparkle.splashFactory,
      dividerColor: line,
      bottomSheetTheme: const BottomSheetThemeData(backgroundColor: surface, surfaceTintColor: Colors.transparent, showDragHandle: false),
      dialogTheme: const DialogThemeData(backgroundColor: surface, surfaceTintColor: Colors.transparent),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: surface3,
        contentTextStyle: const TextStyle(color: text, fontSize: 14),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(rSm)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface2,
        hintStyle: const TextStyle(color: muted),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: line)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: violet, width: 1.5)),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? Colors.white : text2),
        trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? pink : surface3),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
      ),
      appBarTheme: const AppBarTheme(backgroundColor: bg, surfaceTintColor: Colors.transparent, foregroundColor: text, elevation: 0, centerTitle: false),
    );
  }
}

/// One family, one scale. Product-style: tight ratio, weight carries the
/// hierarchy.
class VT {
  VT._();

  static TextStyle display(double size, {Color color = V.text, double? height}) =>
      TextStyle(fontSize: size, fontWeight: FontWeight.w800, letterSpacing: -0.03 * size, height: height ?? 1.05, color: color);

  static TextStyle title(double size, {Color color = V.text, FontWeight weight = FontWeight.w700, double? height}) =>
      TextStyle(fontSize: size, fontWeight: weight, letterSpacing: -0.01 * size, height: height ?? 1.2, color: color);

  static TextStyle body(double size, {Color color = V.text, FontWeight weight = FontWeight.w400, double? height}) =>
      TextStyle(fontSize: size, fontWeight: weight, height: height ?? 1.4, color: color);

  static TextStyle label(double size, {Color color = V.text2, FontWeight weight = FontWeight.w600, double letterSpacing = 0.2}) =>
      TextStyle(fontSize: size, fontWeight: weight, letterSpacing: letterSpacing, height: 1.2, color: color);

  static TextStyle mono(double size, {Color color = V.text2}) => TextStyle(fontSize: size, fontFamily: 'monospace', color: color, height: 1.3);
}
