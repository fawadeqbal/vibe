import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../util/format.dart';
import 'vibe_theme.dart';

/// The primary action: a brand-gradient pill with a soft glow. One per
/// screen at most.
class GradientButton extends StatelessWidget {
  const GradientButton({super.key, required this.label, this.onTap, this.icon, this.busy = false, this.height = 56, this.gradient, this.expand = true, this.foreground = Colors.white});

  final String label;
  final Color foreground;
  final VoidCallback? onTap;
  final IconData? icon;
  final bool busy;
  final double height;
  final Gradient? gradient;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null && !busy;
    final child = AnimatedOpacity(
      duration: const Duration(milliseconds: 150),
      opacity: enabled ? 1 : 0.5,
      child: Container(
        height: height,
        padding: const EdgeInsets.symmetric(horizontal: 24),
        decoration: BoxDecoration(
          gradient: gradient ?? V.brand,
          borderRadius: BorderRadius.circular(height / 2),
          boxShadow: enabled ? [BoxShadow(color: V.pink.withValues(alpha: 0.35), blurRadius: 24, offset: const Offset(0, 8))] : null,
        ),
        child: Row(
          mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (busy)
              SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.2, color: foreground))
            else if (icon != null)
              Icon(icon, size: 20, color: foreground),
            if (busy || icon != null) const SizedBox(width: 10),
            Text(label, style: VT.title(16, color: foreground, weight: FontWeight.w700)),
          ],
        ),
      ),
    );
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: enabled
          ? () {
              HapticFeedback.lightImpact();
              onTap!();
            }
          : null,
      child: child,
    );
  }
}

/// Secondary action: a translucent pill.
class GhostButton extends StatelessWidget {
  const GhostButton({super.key, required this.label, this.onTap, this.icon, this.height = 48, this.color, this.expand = false});

  final String label;
  final VoidCallback? onTap;
  final IconData? icon;
  final double height;
  final Color? color;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    final c = color ?? V.text;
    return Material(
      color: Colors.white.withValues(alpha: 0.07),
      borderRadius: BorderRadius.circular(height / 2),
      child: InkWell(
        borderRadius: BorderRadius.circular(height / 2),
        onTap: onTap,
        child: Container(
          height: height,
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Row(
            mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[Icon(icon, size: 18, color: c), const SizedBox(width: 8)],
              Text(label, style: VT.title(14, color: c, weight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Round icon control for the match screen.
class RoundControl extends StatelessWidget {
  const RoundControl({super.key, required this.icon, required this.onTap, this.size = 52, this.color, this.background, this.label, this.badge});

  final IconData icon;
  final VoidCallback? onTap;
  final double size;
  final Color? color;
  final Color? background;
  final String? label;
  final String? badge;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            Material(
              color: background ?? Colors.white.withValues(alpha: 0.14),
              shape: const CircleBorder(),
              child: InkWell(
                customBorder: const CircleBorder(),
                onTap: onTap,
                child: SizedBox(width: size, height: size, child: Icon(icon, size: size * 0.44, color: color ?? Colors.white)),
              ),
            ),
            if (badge != null)
              Positioned(
                top: -4,
                right: -6,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: V.gold, borderRadius: BorderRadius.circular(10)),
                  child: Text(badge!, style: VT.label(10, color: Colors.black, weight: FontWeight.w800)),
                ),
              ),
          ],
        ),
        if (label != null) ...[
          const SizedBox(height: 6),
          Text(label!, style: VT.label(11, color: Colors.white.withValues(alpha: 0.85))),
        ],
      ],
    );
  }
}

/// Frosted panel over video.
class Glass extends StatelessWidget {
  const Glass({super.key, required this.child, this.radius = 16, this.padding = const EdgeInsets.symmetric(horizontal: 12, vertical: 8), this.opacity = 0.18});
  final Widget child;
  final double radius;
  final EdgeInsets padding;
  final double opacity;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(color: Colors.black.withValues(alpha: opacity), borderRadius: BorderRadius.circular(radius), border: Border.all(color: Colors.white.withValues(alpha: 0.12))),
          child: child,
        ),
      ),
    );
  }
}

/// A card on a screen (not over video).
class Panel extends StatelessWidget {
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.color, this.gradient, this.radius = V.r, this.onTap, this.border});
  final Widget child;
  final EdgeInsets padding;
  final Color? color;
  final Gradient? gradient;
  final double radius;
  final VoidCallback? onTap;
  final Color? border;

  @override
  Widget build(BuildContext context) {
    final box = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: gradient == null ? (color ?? V.surface) : null,
        gradient: gradient,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: border ?? V.line),
      ),
      child: child,
    );
    if (onTap == null) return box;
    return Material(
      color: Colors.transparent,
      child: InkWell(borderRadius: BorderRadius.circular(radius), onTap: onTap, child: box),
    );
  }
}

/// Coins balance chip — lives in most app bars so the number is always
/// in sight (that is half the monetisation).
class CoinChip extends StatelessWidget {
  const CoinChip({super.key, required this.coins, this.onTap, this.compact = false});
  final int coins;
  final VoidCallback? onTap;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: V.gold.withValues(alpha: 0.14),
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 10, vertical: 6),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CoinIcon(size: 16),
              const SizedBox(width: 6),
              Text(Fmt.coins(coins), style: VT.label(13, color: V.gold, weight: FontWeight.w800)),
              if (onTap != null && !compact) ...[const SizedBox(width: 4), const Icon(Icons.add_rounded, size: 16, color: V.gold)],
            ],
          ),
        ),
      ),
    );
  }
}

class CoinIcon extends StatelessWidget {
  const CoinIcon({super.key, this.size = 18});
  final double size;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(shape: BoxShape.circle, gradient: V.goldGrad),
      child: Center(child: Text('¢', style: TextStyle(fontSize: size * 0.62, fontWeight: FontWeight.w900, color: const Color(0xFF6B4200), height: 1))),
    );
  }
}

class GemIcon extends StatelessWidget {
  const GemIcon({super.key, this.size = 18});
  final double size;
  @override
  Widget build(BuildContext context) {
    return Icon(Icons.diamond_rounded, size: size, color: V.gem);
  }
}

/// Network avatar with an initials fallback so the demo works offline.
class VAvatar extends StatelessWidget {
  const VAvatar({super.key, required this.url, required this.name, this.size = 48, this.ring = false});
  final String url;
  final String name;
  final double size;
  final bool ring;

  @override
  Widget build(BuildContext context) {
    final initial = name.trim().isEmpty ? '?' : name.trim()[0].toUpperCase();
    final fallback = Container(
      decoration: const BoxDecoration(shape: BoxShape.circle, gradient: V.brand),
      alignment: Alignment.center,
      child: Text(initial, style: VT.title(size * 0.42, color: Colors.white)),
    );
    final img = url.isEmpty
        ? fallback
        : ClipOval(
            child: Image.network(
              url,
              width: size,
              height: size,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => fallback,
              loadingBuilder: (_, child, progress) => progress == null ? child : fallback,
            ),
          );
    return Container(
      width: size,
      height: size,
      padding: ring ? const EdgeInsets.all(2.5) : EdgeInsets.zero,
      decoration: ring ? const BoxDecoration(shape: BoxShape.circle, gradient: V.brand) : null,
      child: ClipOval(child: SizedBox(width: size, height: size, child: img)),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key, this.action, this.onAction});
  final String text;
  final String? action;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 18, 4, 10),
      child: Row(
        children: [
          Expanded(child: Text(text, style: VT.title(17))),
          if (action != null) TextButton(onPressed: onAction, child: Text(action!, style: VT.label(13, color: V.pink))),
        ],
      ),
    );
  }
}

class Tag extends StatelessWidget {
  const Tag(this.text, {super.key, this.color = V.pink, this.icon});
  final String text;
  final Color color;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(8)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[Icon(icon, size: 12, color: color), const SizedBox(width: 4)],
          Text(text, style: VT.label(11, color: color, weight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.title, required this.body, this.action});
  final IconData icon;
  final String title;
  final String body;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(color: V.surface2, borderRadius: BorderRadius.circular(20)),
              child: Icon(icon, color: V.text2, size: 30),
            ),
            const SizedBox(height: 16),
            Text(title, style: VT.title(18), textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text(body, style: VT.body(14, color: V.text2), textAlign: TextAlign.center),
            if (action != null) ...[const SizedBox(height: 18), action!],
          ],
        ),
      ),
    );
  }
}

/// Bottom sheet with the Vibe look. Returns whatever the sheet pops with.
Future<T?> showVibeSheet<T>(BuildContext context, {required Widget child, bool scrollable = false}) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (ctx) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
      child: Container(
        decoration: const BoxDecoration(color: V.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(V.rLg))),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 10),
              Container(width: 40, height: 4, decoration: BoxDecoration(color: V.lineStrong, borderRadius: BorderRadius.circular(2))),
              const SizedBox(height: 6),
              if (scrollable) Flexible(child: SingleChildScrollView(child: child)) else child,
            ],
          ),
        ),
      ),
    ),
  );
}

void toast(BuildContext context, String message, {bool error = false}) {
  final m = ScaffoldMessenger.maybeOf(context);
  if (m == null) return;
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    content: Row(
      children: [
        Icon(error ? Icons.error_outline_rounded : Icons.check_circle_outline_rounded, size: 18, color: error ? V.bad : V.ok),
        const SizedBox(width: 10),
        Expanded(child: Text(message)),
      ],
    ),
    duration: const Duration(seconds: 2),
  ));
}

/// Breathing rings behind the "Start" button and the searching state.
class PulseRings extends StatefulWidget {
  const PulseRings({super.key, required this.child, this.size = 220, this.color = V.pink, this.active = true});
  final Widget child;
  final double size;
  final Color color;
  final bool active;

  @override
  State<PulseRings> createState() => _PulseRingsState();
}

class _PulseRingsState extends State<PulseRings> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduce = MediaQuery.of(context).disableAnimations;
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          return Stack(
            alignment: Alignment.center,
            children: [
              if (widget.active && !reduce)
                for (final phase in const [0.0, 0.33, 0.66])
                  _ring(((_c.value + phase) % 1.0)),
              widget.child,
            ],
          );
        },
      ),
    );
  }

  Widget _ring(double t) {
    final scale = 0.55 + t * 0.6;
    final opacity = (1 - t) * 0.45;
    return Transform.scale(
      scale: scale,
      child: Container(
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: widget.color.withValues(alpha: opacity), width: 1.5)),
      ),
    );
  }
}
