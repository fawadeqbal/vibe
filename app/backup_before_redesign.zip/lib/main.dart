import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'core/mock/mock_backend.dart';
import 'providers/match_provider.dart';
import 'providers/session_provider.dart';
import 'providers/social_provider.dart';
import 'providers/wallet_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(statusBarColor: Colors.transparent, statusBarIconBrightness: Brightness.light, systemNavigationBarColor: Color(0xFF0B0A10), systemNavigationBarIconBrightness: Brightness.light));

  // One backend, shared. Swap MockBackend for the HTTP client later; the
  // providers do not change.
  final backend = MockBackend();
  final session = SessionProvider(backend);
  final wallet = WalletProvider(backend);
  final social = SocialProvider(backend, wallet);
  final match = MatchProvider(backend, wallet, social, session);

  runApp(
    MultiProvider(
      providers: [
        Provider<MockBackend>.value(value: backend),
        ChangeNotifierProvider.value(value: session),
        ChangeNotifierProvider.value(value: wallet),
        ChangeNotifierProvider.value(value: social),
        ChangeNotifierProvider.value(value: match),
      ],
      child: const VibeApp(),
    ),
  );
}
