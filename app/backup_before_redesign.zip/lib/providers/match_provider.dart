import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../core/mock/mock_backend.dart';
import '../models/models.dart';
import 'session_provider.dart';
import 'social_provider.dart';
import 'wallet_provider.dart';

enum MatchState { idle, searching, connected, ended }

/// Why the last match ended — drives the copy on the ended card.
enum EndReason { skipped, partnerLeft, stopped, reported }

/// The match loop: idle → searching → connected → (next) → searching …
///
/// Owns the local camera (WebRTC local stream, no peer yet — the mock
/// partner is a scripted profile), the filters and what they cost, the
/// skip cooldown, likes, gifts and the in-match chat. Everything the
/// partner "does" comes from `MockBackend.scriptFor`, replayed on timers,
/// so swapping in real socket events later touches only `_apply`.
class MatchProvider extends ChangeNotifier {
  MatchProvider(this._backend, this._wallet, this._social, this._session, {bool cameraEnabled = true}) : _cameraEnabled = cameraEnabled;

  final MockBackend _backend;
  final WalletProvider _wallet;
  final SocialProvider _social;
  final SessionProvider _session;
  final bool _cameraEnabled;

  MatchState _state = MatchState.idle;
  MatchFilters _filters = const MatchFilters();
  Profile? _partner;
  Profile? _lastPartner;
  MatchRecord? _current;
  List<MatchRecord> _history = [];
  EndReason? _endReason;
  final List<ChatMessage> _chat = [];
  bool _likedPartner = false;
  bool _partnerLikedMe = false;
  bool _partnerAskedToBeFriends = false;
  final List<Timer> _timers = [];
  Timer? _ticker;
  Duration _elapsed = Duration.zero;
  int _searchToken = 0;
  final List<DateTime> _recentSkips = [];
  DateTime? _cooldownUntil;
  DateTime? _blurUntil;
  bool _autoBlur = true;
  String? _lastError;

  // Local media
  final RTCVideoRenderer localRenderer = RTCVideoRenderer();
  MediaStream? _localStream;
  bool _rendererReady = false;
  bool _micOn = true;
  bool _camOn = true;
  bool _frontCamera = true;

  // ── read side ─────────────────────────────────────────────────────────

  MatchState get state => _state;
  MatchFilters get filters => _filters;
  Profile? get partner => _partner;
  Profile? get lastPartner => _lastPartner;
  MatchRecord? get current => _current;
  List<MatchRecord> get history => List.unmodifiable(_history.reversed);
  EndReason? get endReason => _endReason;
  List<ChatMessage> get chat => List.unmodifiable(_chat);
  bool get likedPartner => _likedPartner;
  bool get partnerLikedMe => _partnerLikedMe;
  bool get mutualLike => _likedPartner && _partnerLikedMe;
  bool get partnerAskedToBeFriends => _partnerAskedToBeFriends;
  Duration get elapsed => _elapsed;
  bool get micOn => _micOn;
  bool get camOn => _camOn;
  bool get frontCamera => _frontCamera;
  bool get hasLocalVideo => _localStream != null && _rendererReady;
  bool get autoBlur => _autoBlur;
  bool get blurred => _blurUntil != null && _blurUntil!.isAfter(DateTime.now());
  String? get lastError => _lastError;
  bool get isSearching => _state == MatchState.searching;
  bool get isConnected => _state == MatchState.connected;

  /// Seconds left of the skip cooldown, 0 when none.
  int get cooldownSeconds {
    final u = _cooldownUntil;
    if (u == null) return 0;
    final left = u.difference(DateTime.now()).inSeconds;
    return left > 0 ? left + 1 : 0;
  }

  bool get inCooldown => cooldownSeconds > 0;
  int get filterCost => _wallet.filterCost(_filters);

  // Session stats for the profile page
  int get matchesToday => _history.where((r) => _sameDay(r.startedAt, DateTime.now())).length;
  Duration get averageLength {
    final done = _history.where((r) => r.endedAt != null).toList();
    if (done.isEmpty) return Duration.zero;
    final total = done.fold<int>(0, (a, r) => a + r.length.inSeconds);
    return Duration(seconds: total ~/ done.length);
  }

  double get skipRate {
    if (_history.isEmpty) return 0;
    final quick = _history.where((r) => r.endedAt != null && r.length.inSeconds < 10).length;
    return quick / _history.length;
  }

  Future<void> load() async {
    _history = await _backend.loadMatches();
    notifyListeners();
  }

  // ── camera ────────────────────────────────────────────────────────────

  Future<void> ensureCamera() async {
    if (!_cameraEnabled || _localStream != null) return;
    try {
      if (!_rendererReady) {
        await localRenderer.initialize();
        _rendererReady = true;
      }
      final stream = await navigator.mediaDevices.getUserMedia({
        'audio': true,
        'video': {'facingMode': 'user', 'width': 720, 'height': 1280},
      });
      _localStream = stream;
      localRenderer.srcObject = stream;
      _applyTracks();
      notifyListeners();
    } catch (e) {
      _lastError = 'Camera unavailable: $e';
      notifyListeners();
    }
  }

  Future<void> releaseCamera() async {
    final s = _localStream;
    _localStream = null;
    if (_rendererReady) localRenderer.srcObject = null;
    if (s != null) {
      for (final t in s.getTracks()) {
        await t.stop();
      }
      await s.dispose();
    }
    notifyListeners();
  }

  void toggleMic() {
    _micOn = !_micOn;
    _applyTracks();
    notifyListeners();
  }

  void toggleCam() {
    _camOn = !_camOn;
    _applyTracks();
    notifyListeners();
  }

  Future<void> switchCamera() async {
    final s = _localStream;
    if (s == null) return;
    final tracks = s.getVideoTracks();
    if (tracks.isEmpty) return;
    try {
      await Helper.switchCamera(tracks.first);
      _frontCamera = !_frontCamera;
      notifyListeners();
    } catch (_) {}
  }

  void setAutoBlur(bool v) {
    _autoBlur = v;
    notifyListeners();
  }

  void _applyTracks() {
    final s = _localStream;
    if (s == null) return;
    for (final t in s.getAudioTracks()) {
      t.enabled = _micOn;
    }
    for (final t in s.getVideoTracks()) {
      t.enabled = _camOn;
    }
  }

  // ── filters ───────────────────────────────────────────────────────────

  void setFilters(MatchFilters f) {
    _filters = f;
    notifyListeners();
  }

  // ── the loop ──────────────────────────────────────────────────────────

  /// Starts searching. Charges the filter cost up front (a real service
  /// charges per match too); returns false — and stays idle — when the
  /// user cannot afford the filters they picked.
  Future<bool> start() async {
    if (_state == MatchState.searching) return true;
    if (!await _chargeFilters()) return false;
    _endReason = null;
    _lastError = null;
    _state = MatchState.searching;
    notifyListeners();
    return _search();
  }

  Future<bool> _chargeFilters() async {
    final cost = filterCost;
    if (cost > 0 && !await _wallet.spend(cost, 'Filters · ${_filterLabel()}')) {
      _lastError = 'Not enough coins for these filters.';
      _state = MatchState.idle;
      notifyListeners();
      return false;
    }
    return true;
  }

  Future<bool> _search() async {
    unawaited(ensureCamera());
    final token = ++_searchToken;
    try {
      final exclude = {..._social.blocked, if (_lastPartner != null) _lastPartner!.id};
      final p = await _backend.findMatch(_filters, exclude: exclude, boosted: _wallet.isBoosted);
      if (token != _searchToken || _state != MatchState.searching) return true; // cancelled meanwhile
      _connect(p);
    } catch (e) {
      if (token != _searchToken) return true;
      _lastError = 'Could not find anyone: $e';
      _state = MatchState.idle;
      notifyListeners();
    }
    return true;
  }

  void _connect(Profile p) {
    _partner = p;
    _chat.clear();
    _likedPartner = false;
    _partnerLikedMe = false;
    _partnerAskedToBeFriends = false;
    _elapsed = Duration.zero;
    _current = MatchRecord(id: 'mt${DateTime.now().millisecondsSinceEpoch}', partner: p, startedAt: DateTime.now(), coinsSpent: filterCost);
    _blurUntil = _autoBlur && !_wallet.isVip ? DateTime.now().add(const Duration(seconds: 3)) : null;
    _state = MatchState.connected;
    _session.bumpStats(matches: 1);
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      _elapsed += const Duration(seconds: 1);
      notifyListeners();
    });
    for (final ev in _backend.scriptFor(p)) {
      _timers.add(Timer(ev.at, () => _apply(ev)));
    }
    notifyListeners();
  }

  /// A partner-side event. This is the seam a socket would feed.
  void _apply(PartnerEvent ev) {
    if (_state != MatchState.connected || _partner == null) return;
    switch (ev.action) {
      case PartnerAction.message:
        _chat.add(ChatMessage(id: 'pm${DateTime.now().microsecondsSinceEpoch}', fromMe: false, text: ev.text ?? '', at: DateTime.now()));
        break;
      case PartnerAction.like:
        _partnerLikedMe = true;
        _current = _current?.copyWith(likedMe: true);
        _session.bumpStats(likes: 1);
        break;
      case PartnerAction.gift:
        final g = ev.gift;
        if (g != null) {
          _chat.add(ChatMessage(id: 'pg${DateTime.now().microsecondsSinceEpoch}', fromMe: false, text: 'Sent you a ${g.name}', at: DateTime.now(), gift: g));
          _current = _current?.copyWith(giftsReceived: (_current?.giftsReceived ?? 0) + 1);
          unawaited(_wallet.receiveGems(g.gems, '${g.name} from ${_partner!.name}'));
        }
        break;
      case PartnerAction.friendRequest:
        _partnerAskedToBeFriends = true;
        _social.receiveRequest(_partner!);
        break;
      case PartnerAction.leave:
        _end(EndReason.partnerLeft);
        return;
    }
    notifyListeners();
  }

  /// Swipe to the next person. Enforces the skip cooldown (5 quick skips
  /// a minute, then a 10 s wait) unless bypassed with coins.
  Future<bool> next({bool payToBypass = false}) async {
    if (_state == MatchState.connected) {
      if (inCooldown) {
        if (!payToBypass || !await _wallet.spend(Economy.skipCooldownBypassCost, 'Skip cooldown bypass')) return false;
        _cooldownUntil = null;
      }
      _noteSkip();
      _end(EndReason.skipped, keepGoing: true);
      if (!await _chargeFilters()) return false;
      return _search();
    }
    return start();
  }

  /// Pays to skip the cooldown; returns false when unaffordable.
  Future<bool> bypassCooldown() => next(payToBypass: true);

  void stop() {
    if (_state == MatchState.connected) {
      _end(EndReason.stopped);
    } else if (_state == MatchState.searching) {
      _searchToken++;
      _state = MatchState.idle;
      notifyListeners();
    }
  }

  /// Back to idle from the ended card.
  void dismissEnded() {
    if (_state == MatchState.ended) {
      _state = MatchState.idle;
      _partner = null;
      notifyListeners();
    }
  }

  void _noteSkip() {
    final now = DateTime.now();
    _recentSkips.add(now);
    _recentSkips.removeWhere((t) => now.difference(t) > const Duration(minutes: 1));
    if (_recentSkips.length >= Economy.skipsBeforeCooldown && (_elapsed.inSeconds < 10)) {
      _cooldownUntil = now.add(Economy.skipCooldown);
      _recentSkips.clear();
    }
  }

  void _end(EndReason reason, {bool keepGoing = false}) {
    for (final t in _timers) {
      t.cancel();
    }
    _timers.clear();
    _ticker?.cancel();
    _ticker = null;
    if (_current != null) {
      final rec = _current!.copyWith(endedAt: DateTime.now());
      _history.add(rec);
      unawaited(_backend.saveMatches(_history));
      _current = null;
    }
    _lastPartner = _partner;
    _endReason = reason;
    _state = keepGoing ? MatchState.searching : MatchState.ended;
    if (!keepGoing) unawaited(releaseCamera());
    notifyListeners();
  }

  // ── in-match actions ──────────────────────────────────────────────────

  void like() {
    if (_state != MatchState.connected || _likedPartner) return;
    _likedPartner = true;
    _current = _current?.copyWith(liked: true);
    notifyListeners();
  }

  void sendMessage(String text) {
    final t = text.trim();
    if (_state != MatchState.connected || t.isEmpty) return;
    _chat.add(ChatMessage(id: 'mm${DateTime.now().microsecondsSinceEpoch}', fromMe: true, text: t, at: DateTime.now()));
    notifyListeners();
  }

  /// Sends a gift: coins out, gems to the partner (the mock partner is not
  /// a real account, so the gems simply disappear — as they would into
  /// another user's wallet). False when unaffordable.
  Future<bool> sendGift(Gift g) async {
    if (_state != MatchState.connected || _partner == null) return false;
    if (!await _wallet.spend(g.coins, '${g.name} to ${_partner!.name}', kind: TxKind.gift)) return false;
    _chat.add(ChatMessage(id: 'mg${DateTime.now().microsecondsSinceEpoch}', fromMe: true, text: 'Sent a ${g.name}', at: DateTime.now(), gift: g));
    _current = _current?.copyWith(giftsSent: (_current?.giftsSent ?? 0) + 1, coinsSpent: (_current?.coinsSpent ?? 0) + g.coins);
    // A gift usually earns a thank-you.
    _timers.add(Timer(const Duration(seconds: 2), () => _apply(PartnerEvent(Duration.zero, PartnerAction.message, text: 'omg thank you for the ${g.name.toLowerCase()} ${g.emoji}'))));
    notifyListeners();
    return true;
  }

  /// Friend request during the match. False when it could not be paid for.
  Future<bool> addFriend() async {
    final p = _partner;
    if (_state != MatchState.connected || p == null) return false;
    return _social.sendRequest(p);
  }

  FriendState get friendState => _partner == null ? FriendState.none : _social.stateOf(_partner!.id);

  Future<void> report(ReportReason reason, {String? note, bool block = false}) async {
    final p = _partner;
    if (p == null) return;
    await _backend.report(userId: p.id, reason: reason, note: note);
    if (block) await _social.block(p);
    _end(EndReason.reported);
  }

  Future<void> blockPartner() async {
    final p = _partner;
    if (p == null) return;
    await _social.block(p);
    _end(EndReason.reported);
  }

  /// Call the last person again (paid). False when unaffordable or nobody.
  Future<bool> reconnect() async {
    final p = _lastPartner;
    if (p == null || _state == MatchState.connected) return false;
    if (!await _wallet.spend(Economy.reconnectCost, 'Reconnect with ${p.name}')) return false;
    _state = MatchState.searching;
    _lastPartner = null;
    notifyListeners();
    unawaited(ensureCamera());
    await Future<void>.delayed(const Duration(milliseconds: 1500));
    if (_state != MatchState.searching) return true;
    _connect(p);
    return true;
  }

  void clearError() {
    _lastError = null;
    notifyListeners();
  }

  String _filterLabel() {
    final parts = <String>[];
    if (_filters.gender == GenderFilter.women) parts.add('women');
    if (_filters.gender == GenderFilter.men) parts.add('men');
    if (_filters.countryCode != null) parts.add(_filters.countryCode!);
    return parts.join(' · ');
  }

  static bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  @override
  void dispose() {
    for (final t in _timers) {
      t.cancel();
    }
    _ticker?.cancel();
    releaseCamera();
    if (_rendererReady) localRenderer.dispose();
    super.dispose();
  }
}
