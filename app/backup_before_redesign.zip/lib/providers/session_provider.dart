import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';

import '../core/mock/mock_backend.dart';
import '../models/models.dart';

/// Who is signed in, and how far through first-run they are.
///
/// Flow: splash (restore) → welcome → sign-in → profile setup → permissions
/// → home. `onboarded` flips only when the profile is complete enough to
/// match (name, age, gender) and the permission step was passed.
class SessionProvider extends ChangeNotifier {
  SessionProvider(this._backend);

  final MockBackend _backend;

  Profile? _me;
  bool _booting = true;
  bool _onboarded = false;
  bool _busy = false;
  bool _cameraGranted = false;
  bool _micGranted = false;

  Profile? get me => _me;
  bool get booting => _booting;
  bool get signedIn => _me != null;
  bool get onboarded => _onboarded;
  bool get busy => _busy;
  bool get cameraGranted => _cameraGranted;
  bool get micGranted => _micGranted;
  bool get permissionsGranted => _cameraGranted && _micGranted;

  /// True once the profile has the three things the matcher needs.
  bool get profileReady => _me != null && _me!.name.trim().isNotEmpty && _me!.age >= 18;

  Future<void> restore() async {
    try {
      await _backend.init();
      _me = await _backend.restoreProfile();
      _onboarded = _backend.onboarded;
      await refreshPermissions();
    } finally {
      _booting = false;
      notifyListeners();
    }
  }

  Future<void> refreshPermissions() async {
    try {
      _cameraGranted = await Permission.camera.isGranted;
      _micGranted = await Permission.microphone.isGranted;
    } catch (_) {
      // Desktop / web / test: no permission plugin. Treat as granted so the
      // flow can be walked through.
      _cameraGranted = true;
      _micGranted = true;
    }
    notifyListeners();
  }

  Future<bool> requestPermissions() async {
    try {
      final results = await [Permission.camera, Permission.microphone].request();
      _cameraGranted = results[Permission.camera]?.isGranted ?? false;
      _micGranted = results[Permission.microphone]?.isGranted ?? false;
    } catch (_) {
      _cameraGranted = true;
      _micGranted = true;
    }
    notifyListeners();
    return permissionsGranted;
  }

  Future<void> signIn({required String method, String? phone}) async {
    _busy = true;
    notifyListeners();
    try {
      _me = await _backend.signIn(method: method, phone: phone);
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  Future<void> saveProfile(Profile p) async {
    _me = p;
    await _backend.saveProfile(p);
    notifyListeners();
  }

  Future<void> finishOnboarding() async {
    _onboarded = true;
    await _backend.setOnboarded(true);
    notifyListeners();
  }

  /// Mocked selfie verification: grants the badge after a short "review".
  Future<bool> verifySelfie() async {
    if (_me == null) return false;
    _busy = true;
    notifyListeners();
    try {
      final ok = await _backend.verifySelfie();
      if (ok) await saveProfile(_me!.copyWith(verified: true));
      return ok;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  void bumpStats({int matches = 0, int likes = 0}) {
    if (_me == null) return;
    _me = _me!.copyWith(matches: _me!.matches + matches, likes: _me!.likes + likes);
    _backend.saveProfile(_me!);
    notifyListeners();
  }

  Future<void> signOut() async {
    await _backend.signOut();
    _me = null;
    _onboarded = false;
    notifyListeners();
  }
}
