import 'dart:async';

import 'package:flutter/foundation.dart';

import '../core/mock/mock_backend.dart';
import '../models/models.dart';
import 'wallet_provider.dart';

/// Friends, requests, blocks, chats with friends, and the "liked you" list.
/// The partner side is simulated: requests get accepted after a moment,
/// messages get a reply.
class SocialProvider extends ChangeNotifier {
  SocialProvider(this._backend, this._wallet);

  final MockBackend _backend;
  final WalletProvider _wallet;

  List<Friend> _friends = [];
  Map<String, List<ChatMessage>> _chats = {};
  Set<String> _blocked = {};
  List<Profile> _likedYou = [];
  final List<Timer> _timers = [];
  bool _loaded = false;

  List<Friend> get friends => _friends.where((f) => f.state == FriendState.friends).toList()
    ..sort((a, b) => (b.lastMessage == null ? b.since : _lastAt(b)).compareTo(a.lastMessage == null ? a.since : _lastAt(a)));
  List<Friend> get incoming => _friends.where((f) => f.state == FriendState.incoming).toList();
  List<Friend> get requested => _friends.where((f) => f.state == FriendState.requested).toList();
  Set<String> get blocked => _blocked;
  List<Profile> get likedYou => _likedYou;
  bool get loaded => _loaded;
  int get unreadTotal => _friends.fold(0, (a, f) => a + f.unread);

  DateTime _lastAt(Friend f) {
    final list = _chats[f.profile.id];
    return list == null || list.isEmpty ? f.since : list.last.at;
  }

  Future<void> load() async {
    _friends = await _backend.loadFriends();
    _chats = await _backend.loadChats();
    _blocked = await _backend.loadBlocked();
    _likedYou = _backend.likedYou(exclude: _friends.map((f) => f.profile.id).toSet());
    _loaded = true;
    notifyListeners();
  }

  FriendState stateOf(String userId) {
    if (_blocked.contains(userId)) return FriendState.blocked;
    for (final f in _friends) {
      if (f.profile.id == userId) return f.state;
    }
    return FriendState.none;
  }

  List<ChatMessage> messages(String friendId) => List.unmodifiable(_chats[friendId] ?? const []);

  Friend? friend(String id) {
    for (final f in _friends) {
      if (f.profile.id == id) return f;
    }
    return null;
  }

  // ── requests ──────────────────────────────────────────────────────────

  /// Sends a request; the mock partner accepts within a few seconds (most
  /// of the time). Returns false when the request could not be paid for.
  Future<bool> sendRequest(Profile p) async {
    final existing = stateOf(p.id);
    if (existing == FriendState.friends || existing == FriendState.requested) return true;
    if (existing == FriendState.incoming) return accept(p.id);
    if (!await _wallet.payFriendRequest(p.name)) return false;
    _upsert(Friend(profile: p, state: FriendState.requested, since: DateTime.now()));
    _timers.add(Timer(Duration(seconds: 2 + p.id.hashCode.abs() % 4), () {
      final f = friend(p.id);
      if (f == null || f.state != FriendState.requested) return;
      if (p.id.hashCode.abs() % 5 == 0) {
        _friends.removeWhere((x) => x.profile.id == p.id); // declined, quietly
      } else {
        _upsert(f.copyWith(state: FriendState.friends, online: true));
      }
      _persist();
    }));
    await _persist();
    return true;
  }

  /// The partner asked first (a scripted PartnerAction.friendRequest).
  void receiveRequest(Profile p) {
    if (stateOf(p.id) != FriendState.none) return;
    _upsert(Friend(profile: p, state: FriendState.incoming, since: DateTime.now()));
    _persist();
  }

  Future<bool> accept(String id) async {
    final f = friend(id);
    if (f == null) return false;
    _upsert(f.copyWith(state: FriendState.friends, online: true));
    await _persist();
    return true;
  }

  Future<void> decline(String id) async {
    _friends.removeWhere((f) => f.profile.id == id);
    await _persist();
  }

  Future<void> remove(String id) async {
    _friends.removeWhere((f) => f.profile.id == id);
    _chats.remove(id);
    await _persist();
  }

  // ── blocks ────────────────────────────────────────────────────────────

  Future<void> block(Profile p) async {
    _blocked.add(p.id);
    _friends.removeWhere((f) => f.profile.id == p.id);
    _chats.remove(p.id);
    await _backend.saveBlocked(_blocked);
    await _persist();
  }

  Future<void> unblock(String id) async {
    _blocked.remove(id);
    await _backend.saveBlocked(_blocked);
    notifyListeners();
  }

  // ── chat ──────────────────────────────────────────────────────────────

  Future<void> sendMessage(String friendId, String text) async {
    final t = text.trim();
    if (t.isEmpty) return;
    _append(friendId, ChatMessage(id: 'm${DateTime.now().microsecondsSinceEpoch}', fromMe: true, text: t, at: DateTime.now()));
    await _persist();
    _scheduleReply(friendId);
  }

  Future<bool> sendGift(String friendId, Gift gift) async {
    final f = friend(friendId);
    if (f == null) return false;
    if (!await _wallet.spend(gift.coins, '${gift.name} to ${f.profile.name}', kind: TxKind.gift)) return false;
    _append(friendId, ChatMessage(id: 'g${DateTime.now().microsecondsSinceEpoch}', fromMe: true, text: 'Sent a ${gift.name}', at: DateTime.now(), gift: gift));
    await _persist();
    _scheduleReply(friendId, thanks: true);
    return true;
  }

  void markRead(String friendId) {
    final f = friend(friendId);
    if (f == null || f.unread == 0) return;
    _upsert(f.copyWith(unread: 0));
    _persist();
  }

  void _scheduleReply(String friendId, {bool thanks = false}) {
    _timers.add(Timer(Duration(seconds: 2 + friendId.hashCode.abs() % 5), () {
      if (friend(friendId) == null) return;
      final text = thanks ? 'aww thank you!! 🥹' : _backend.friendReply();
      _append(friendId, ChatMessage(id: 'r${DateTime.now().microsecondsSinceEpoch}', fromMe: false, text: text, at: DateTime.now()), unread: true);
      _persist();
    }));
  }

  void _append(String friendId, ChatMessage m, {bool unread = false}) {
    final list = _chats.putIfAbsent(friendId, () => []);
    list.add(m);
    if (list.length > 300) list.removeRange(0, list.length - 300);
    final f = friend(friendId);
    if (f != null) _upsert(f.copyWith(lastMessage: m.gift != null ? '${m.gift!.emoji} ${m.gift!.name}' : m.text, unread: unread ? f.unread + 1 : f.unread));
  }

  void _upsert(Friend f) {
    final i = _friends.indexWhere((x) => x.profile.id == f.profile.id);
    if (i >= 0) {
      _friends[i] = f;
    } else {
      _friends.add(f);
    }
  }

  Future<void> _persist() async {
    await _backend.saveFriends(_friends);
    await _backend.saveChats(_chats);
    notifyListeners();
  }

  @override
  void dispose() {
    for (final t in _timers) {
      t.cancel();
    }
    super.dispose();
  }
}
