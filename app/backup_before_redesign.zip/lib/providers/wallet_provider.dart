import 'package:flutter/foundation.dart';

import '../core/mock/mock_backend.dart';
import '../core/util/format.dart';
import '../models/models.dart';

/// Coins, gems, VIP, boosts, and the ledger. Every coin that moves goes
/// through `spend`/`earn`, which is also where the "not enough coins" answer
/// comes from — screens react to it by opening the store.
class WalletProvider extends ChangeNotifier {
  WalletProvider(this._backend, {DateTime Function()? clock}) : _clock = clock ?? DateTime.now;

  final MockBackend _backend;
  final DateTime Function() _clock;

  Wallet _wallet = const Wallet(coins: 0, gems: 0);
  List<Transaction> _tx = [];
  bool _loaded = false;

  Wallet get wallet => _wallet;
  int get coins => _wallet.coins;
  int get gems => _wallet.gems;
  bool get isVip => _wallet.vipUntil != null && _wallet.vipUntil!.isAfter(_clock());
  bool get isBoosted => _wallet.boostUntil != null && _wallet.boostUntil!.isAfter(_clock());
  List<Transaction> get transactions => List.unmodifiable(_tx.reversed);
  bool get loaded => _loaded;

  Future<void> load() async {
    _wallet = await _backend.loadWallet();
    _tx = await _backend.loadTransactions();
    if (_tx.isEmpty && _wallet.coins == Economy.welcomeCoins) {
      _tx.add(_entry(TxKind.earn, 'Welcome bonus', coins: Economy.welcomeCoins));
      await _backend.saveTransactions(_tx);
    }
    _loaded = true;
    notifyListeners();
  }

  // ── core moves ────────────────────────────────────────────────────────

  /// Takes coins. False (and nothing happens) when the balance is short.
  Future<bool> spend(int amount, String title, {TxKind kind = TxKind.spend}) async {
    if (amount <= 0) return true;
    if (_wallet.coins < amount) return false;
    _wallet = _wallet.copyWith(coins: _wallet.coins - amount);
    _tx.add(_entry(kind, title, coins: -amount));
    await _persist();
    return true;
  }

  Future<void> earn(int amount, String title, {TxKind kind = TxKind.earn}) async {
    if (amount <= 0) return;
    _wallet = _wallet.copyWith(coins: _wallet.coins + amount);
    _tx.add(_entry(kind, title, coins: amount));
    await _persist();
  }

  Future<void> receiveGems(int gems, String title) async {
    if (gems <= 0) return;
    _wallet = _wallet.copyWith(gems: _wallet.gems + gems);
    _tx.add(_entry(TxKind.gift, title, coins: 0, gems: gems));
    await _persist();
  }

  // ── store ─────────────────────────────────────────────────────────────

  Future<void> creditPack(CoinPack pack, PaymentMethod method, String receipt) async {
    final bonus = (pack.coins * pack.bonusPercent / 100).round();
    _wallet = _wallet.copyWith(coins: _wallet.coins + pack.coins + bonus);
    _tx.add(_entry(TxKind.purchase, '${pack.name} pack${bonus > 0 ? ' +$bonus bonus' : ''}', coins: pack.coins + bonus, usd: pack.usd, method: method, receipt: receipt));
    await _persist();
  }

  Future<void> activateVip(VipPlan plan, PaymentMethod method, String receipt) async {
    final now = _clock();
    final from = isVip ? _wallet.vipUntil! : now;
    final until = from.add(plan.trialDays > 0 && !isVip ? Duration(days: plan.trialDays) + plan.length : plan.length);
    _wallet = _wallet.copyWith(vipUntil: until, coins: _wallet.coins + Economy.vipMonthlyBonusCoins);
    _tx.add(_entry(TxKind.vip, 'VIP ${plan.label.toLowerCase()}${plan.trialDays > 0 && from == now ? ' (trial)' : ''}', coins: Economy.vipMonthlyBonusCoins, usd: plan.usd, method: method, receipt: receipt));
    await _persist();
  }

  Future<void> cancelVip() async {
    _wallet = _wallet.copyWith(clearVip: true);
    _tx.add(_entry(TxKind.vip, 'VIP cancelled', coins: 0));
    await _persist();
  }

  Future<bool> boost() async {
    if (isBoosted) return true;
    if (!await spend(Economy.boostCost, 'Boost · 30 min priority')) return false;
    _wallet = _wallet.copyWith(boostUntil: _clock().add(Economy.boostLength));
    await _persist();
    return true;
  }

  // ── free coins ────────────────────────────────────────────────────────

  bool get checkedInToday => Fmt.sameDay(_wallet.lastCheckIn, _clock());

  /// The day (0-based) the next check-in will award, given the streak rule:
  /// consecutive days advance it, a missed day resets to 0, day 7 wraps.
  int get nextCheckInDay {
    final last = _wallet.lastCheckIn;
    if (last == null) return 0;
    final today = _clock();
    final yesterday = today.subtract(const Duration(days: 1));
    if (Fmt.sameDay(last, today)) return _wallet.streakDay % Economy.checkInRewards.length;
    if (Fmt.sameDay(last, yesterday)) return _wallet.streakDay % Economy.checkInRewards.length;
    return 0;
  }

  /// Awards today's check-in. Null when already claimed today.
  Future<int?> checkIn() async {
    if (checkedInToday) return null;
    final day = nextCheckInDay;
    final reward = Economy.checkInRewards[day];
    _wallet = _wallet.copyWith(streakDay: day + 1, lastCheckIn: _clock());
    await earn(reward, 'Daily check-in · day ${day + 1}');
    return reward;
  }

  int get adsLeftToday {
    if (!Fmt.sameDay(_wallet.adsDay, _clock())) return Economy.rewardedAdsPerDay;
    return (Economy.rewardedAdsPerDay - _wallet.adsWatchedToday).clamp(0, Economy.rewardedAdsPerDay);
  }

  /// Called after the ad "played". Null when the daily cap is hit.
  Future<int?> rewardAd() async {
    if (adsLeftToday <= 0) return null;
    final today = _clock();
    final count = Fmt.sameDay(_wallet.adsDay, today) ? _wallet.adsWatchedToday + 1 : 1;
    _wallet = _wallet.copyWith(adsWatchedToday: count, adsDay: today);
    await earn(Economy.rewardedAdCoins, 'Watched an ad');
    return Economy.rewardedAdCoins;
  }

  Future<int?> claimProfileBonus() async {
    if (_wallet.profileBonusClaimed) return null;
    _wallet = _wallet.copyWith(profileBonusClaimed: true);
    await earn(Economy.profileCompleteCoins, 'Profile completed');
    return Economy.profileCompleteCoins;
  }

  Future<int> claimInvite(String friendName) async {
    await earn(Economy.inviteRewardCoins, 'Invited $friendName');
    return Economy.inviteRewardCoins;
  }

  // ── match costs ───────────────────────────────────────────────────────

  int get freeFriendRequestsLeft {
    if (!Fmt.sameDay(_wallet.friendRequestsDay, _clock())) return Economy.freeFriendRequestsPerDay;
    return (Economy.freeFriendRequestsPerDay - _wallet.freeFriendRequestsToday).clamp(0, Economy.freeFriendRequestsPerDay);
  }

  /// Uses a free daily request when one is left, else charges coins.
  Future<bool> payFriendRequest(String partnerName) async {
    if (freeFriendRequestsLeft > 0) {
      final today = _clock();
      final used = Fmt.sameDay(_wallet.friendRequestsDay, today) ? _wallet.freeFriendRequestsToday + 1 : 1;
      _wallet = _wallet.copyWith(freeFriendRequestsToday: used, friendRequestsDay: today);
      await _persist();
      return true;
    }
    return spend(Economy.friendRequestCost, 'Friend request · $partnerName');
  }

  int filterCost(MatchFilters f) => f.costFor(vip: isVip);

  // ── gems ──────────────────────────────────────────────────────────────

  bool get canCashOut => _wallet.gems >= Economy.cashoutMinGems;

  Future<void> cashOut(int gems, PaymentMethod method, String account) async {
    await _backend.requestCashout(gems: gems, method: method, account: account);
    _wallet = _wallet.copyWith(gems: _wallet.gems - gems);
    _tx.add(_entry(TxKind.cashout, 'Cash-out to ${method.label}', coins: 0, gems: -gems, usd: gems * Economy.usdPerGem, method: method));
    await _persist();
  }

  // ── helpers ───────────────────────────────────────────────────────────

  Transaction _entry(TxKind kind, String title, {required int coins, int gems = 0, double usd = 0, PaymentMethod? method, String? receipt}) {
    return Transaction(id: 't${_clock().microsecondsSinceEpoch}', kind: kind, title: title, coins: coins, gems: gems, usd: usd, at: _clock(), method: method, receipt: receipt);
  }

  Future<void> _persist() async {
    await _backend.saveWallet(_wallet);
    await _backend.saveTransactions(_tx);
    notifyListeners();
  }

  /// Test seam.
  @visibleForTesting
  void debugSet(Wallet w) {
    _wallet = w;
    notifyListeners();
  }
}
