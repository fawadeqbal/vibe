import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/vibe_theme.dart';
import '../../providers/match_provider.dart';
import '../../providers/social_provider.dart';
import '../match/match_screen.dart';
import '../profile/profile_screen.dart';
import '../social/chats_screen.dart';
import '../store/store_screen.dart';

/// Four tabs. Match is the app; the other three exist to keep people
/// coming back to it (friends), to pay (store) and to trust it (profile).
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  void go(int i) => setState(() => _index = i);

  @override
  Widget build(BuildContext context) {
    final unread = context.select<SocialProvider, int>((s) => s.unreadTotal + s.incoming.length);
    final live = context.select<MatchProvider, bool>((m) => m.isConnected || m.isSearching);
    // While a match is live the tab bar hides: the match owns the screen.
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: [
          MatchScreen(onOpenStore: () => go(2), onOpenChats: () => go(1)),
          ChatsScreen(onFindPeople: () => go(0)),
          const StoreScreen(),
          ProfileScreen(onOpenStore: () => go(2)),
        ],
      ),
      bottomNavigationBar: live && _index == 0
          ? null
          : Container(
              decoration: const BoxDecoration(color: V.bg2, border: Border(top: BorderSide(color: V.line))),
              child: SafeArea(
                top: false,
                child: SizedBox(
                  height: 64,
                  child: Row(
                    children: [
                      _tab(0, Icons.videocam_rounded, 'Match'),
                      _tab(1, Icons.chat_bubble_rounded, 'Chats', badge: unread),
                      _tab(2, Icons.storefront_rounded, 'Store'),
                      _tab(3, Icons.person_rounded, 'Me'),
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  Widget _tab(int i, IconData icon, String label, {int badge = 0}) {
    final on = i == _index;
    return Expanded(
      child: InkWell(
        onTap: () => go(i),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                ShaderMask(
                  shaderCallback: (r) => (on ? V.brand : const LinearGradient(colors: [V.muted, V.muted])).createShader(r),
                  child: Icon(icon, size: 24, color: Colors.white),
                ),
                if (badge > 0)
                  Positioned(
                    right: -8,
                    top: -4,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                      decoration: BoxDecoration(color: V.pink, borderRadius: BorderRadius.circular(8)),
                      child: Text('$badge', style: VT.label(10, color: Colors.white, weight: FontWeight.w800)),
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(label, style: VT.label(11, color: on ? V.text : V.muted)),
          ],
        ),
      ),
    );
  }
}
