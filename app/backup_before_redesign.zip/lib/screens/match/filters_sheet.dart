import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/mock/mock_data.dart';
import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../../models/models.dart';
import '../../providers/match_provider.dart';
import '../../providers/wallet_provider.dart';
import '../store/vip_screen.dart';

/// Who to match with. Paid filters show their price; VIP shows "free".
Future<void> showFiltersSheet(BuildContext context) {
  return showVibeSheet(context, scrollable: true, child: const _FiltersSheet());
}

class _FiltersSheet extends StatefulWidget {
  const _FiltersSheet();

  @override
  State<_FiltersSheet> createState() => _FiltersSheetState();
}

class _FiltersSheetState extends State<_FiltersSheet> {
  late MatchFilters _f;
  late bool _autoBlur;

  @override
  void initState() {
    super.initState();
    final m = context.read<MatchProvider>();
    _f = m.filters;
    _autoBlur = m.autoBlur;
  }

  @override
  Widget build(BuildContext context) {
    final vip = context.watch<WalletProvider>().isVip;
    final cost = _f.costFor(vip: vip);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Who do you want to meet?', style: VT.title(20)),
          const SizedBox(height: 4),
          Text(vip ? 'VIP: every filter is free.' : 'Filters cost coins per match. VIP makes them free.', style: VT.body(13, color: V.text2)),
          const SizedBox(height: 18),
          Text('Gender', style: VT.label(13)),
          const SizedBox(height: 8),
          Row(
            children: [
              _seg('Anyone', GenderFilter.anyone, null, vip),
              const SizedBox(width: 8),
              _seg('Women', GenderFilter.women, Economy.genderFilterCost, vip),
              const SizedBox(width: 8),
              _seg('Men', GenderFilter.men, Economy.genderFilterCost, vip),
            ],
          ),
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(child: Text('Country', style: VT.label(13))),
              Tag(vip ? 'Free' : '${Economy.regionFilterCost} coins', color: vip ? V.ok : V.gold),
            ],
          ),
          const SizedBox(height: 8),
          Panel(
            padding: EdgeInsets.zero,
            color: V.surface2,
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _f.countryCode ?? '',
                isExpanded: true,
                dropdownColor: V.surface2,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                borderRadius: BorderRadius.circular(14),
                items: [
                  DropdownMenuItem(value: '', child: Text('🌍  Anywhere', style: VT.body(15))),
                  for (final c in MockData.countries) DropdownMenuItem(value: c.code, child: Text('${c.flag}  ${c.name}', style: VT.body(15))),
                ],
                onChanged: (v) => setState(() => _f = v == null || v.isEmpty ? _f.copyWith(clearCountry: true) : _f.copyWith(countryCode: v)),
              ),
            ),
          ),
          const SizedBox(height: 18),
          _toggle('Safe mode', 'Only match with verified profiles.', _f.safeMode, (v) => setState(() => _f = _f.copyWith(safeMode: v))),
          const SizedBox(height: 8),
          _toggle('Blur the first 3 seconds', vip ? 'Off for VIP by default; you can keep it on.' : 'Both videos start blurred, so nobody gets flashed.', _autoBlur, (v) => setState(() => _autoBlur = v)),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: Text(cost == 0 ? 'Free to match' : '$cost coins per match', style: VT.title(15, color: cost == 0 ? V.ok : V.gold)),
              ),
              if (!vip && cost > 0)
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VipScreen()));
                  },
                  child: Text('Get VIP · filters free', style: VT.label(13, color: V.pink)),
                ),
            ],
          ),
          const SizedBox(height: 10),
          GradientButton(
            label: 'Apply',
            onTap: () {
              final m = context.read<MatchProvider>();
              m.setFilters(_f);
              m.setAutoBlur(_autoBlur);
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }

  Widget _seg(String label, GenderFilter g, int? cost, bool vip) {
    final on = _f.gender == g;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _f = _f.copyWith(gender: g)),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          height: 58,
          decoration: BoxDecoration(gradient: on ? V.brand : null, color: on ? null : V.surface2, borderRadius: BorderRadius.circular(14)),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(label, style: VT.title(14, weight: FontWeight.w600, color: on ? Colors.white : V.text2)),
              if (cost != null) Text(vip ? 'free' : '$cost coins', style: VT.label(11, color: on ? Colors.white.withValues(alpha: 0.85) : V.gold)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _toggle(String title, String body, bool value, ValueChanged<bool> onChanged) {
    return Panel(
      padding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
      child: Row(
        children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: VT.title(14, weight: FontWeight.w600)), Text(body, style: VT.body(12, color: V.text2))]),
          ),
          Switch(value: value, onChanged: onChanged),
        ],
      ),
    );
  }
}
