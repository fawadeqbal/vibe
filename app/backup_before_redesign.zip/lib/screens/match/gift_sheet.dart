import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/mock/mock_data.dart';
import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../../core/util/format.dart';
import '../../models/models.dart';
import '../../providers/wallet_provider.dart';
import '../store/store_screen.dart';

/// Pick a gift. Returns the gift, or null. The caller pays; when the
/// balance is short the sheet offers the store instead.
Future<Gift?> showGiftSheet(BuildContext context, {required String toName}) {
  return showVibeSheet<Gift>(context, child: _GiftSheet(toName: toName));
}

class _GiftSheet extends StatelessWidget {
  const _GiftSheet({required this.toName});
  final String toName;

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Expanded(child: Text('Send $toName a gift', style: VT.title(20))),
              CoinChip(
                coins: wallet.coins,
                onTap: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoreScreen(asPage: true)));
                },
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text('They keep ${(Economy.giftGemShare * 100).round()}% as gems they can cash out.', style: VT.body(13, color: V.text2)),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 0.95,
            children: [
              for (final g in MockData.gifts)
                Builder(builder: (context) {
                  final can = wallet.coins >= g.coins;
                  return Panel(
                    color: V.surface2,
                    padding: const EdgeInsets.all(10),
                    onTap: () => Navigator.of(context).pop(g),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(g.emoji, style: const TextStyle(fontSize: 34)),
                        const SizedBox(height: 6),
                        Text(g.name, style: VT.title(13, weight: FontWeight.w600)),
                        const SizedBox(height: 4),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const CoinIcon(size: 13),
                            const SizedBox(width: 4),
                            Text(Fmt.coins(g.coins), style: VT.label(12, color: can ? V.gold : V.muted, weight: FontWeight.w800)),
                          ],
                        ),
                      ],
                    ),
                  );
                }),
            ],
          ),
        ],
      ),
    );
  }
}

/// The floating "+20 🌹" moment when a gift is sent or received.
class GiftBurst extends StatefulWidget {
  const GiftBurst({super.key, required this.gift, required this.received});
  final Gift gift;
  final bool received;

  @override
  State<GiftBurst> createState() => _GiftBurstState();
}

class _GiftBurstState extends State<GiftBurst> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..forward();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final t = Curves.easeOutCubic.transform(_c.value);
        final fade = _c.value < 0.7 ? 1.0 : 1 - (_c.value - 0.7) / 0.3;
        return Opacity(
          opacity: fade.clamp(0, 1),
          child: Transform.translate(
            offset: Offset(0, -60 * t),
            child: Transform.scale(
              scale: 0.6 + 0.6 * t,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(widget.gift.emoji, style: const TextStyle(fontSize: 72)),
                  Glass(child: Text(widget.received ? '${widget.gift.name} · +${widget.gift.gems} gems' : 'Sent a ${widget.gift.name}', style: VT.title(14, color: Colors.white))),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
