import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:provider/provider.dart';

import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../../core/util/format.dart';
import '../../models/models.dart';
import '../../providers/match_provider.dart';
import '../../providers/session_provider.dart';
import '../../providers/wallet_provider.dart';
import '../store/store_screen.dart';
import '../store/vip_screen.dart';
import 'filters_sheet.dart';
import 'gift_sheet.dart';
import 'report_sheet.dart';

/// The app. Four looks on one screen: lobby (idle), searching, connected,
/// ended. The local camera fills the background in the first two; during a
/// match the partner takes the stage and you shrink to a corner.
class MatchScreen extends StatefulWidget {
  const MatchScreen({super.key, required this.onOpenStore, required this.onOpenChats});
  final VoidCallback onOpenStore;
  final VoidCallback onOpenChats;

  @override
  State<MatchScreen> createState() => _MatchScreenState();
}

class _MatchScreenState extends State<MatchScreen> {
  final _message = TextEditingController();
  final _chatScroll = ScrollController();
  Gift? _burst;
  bool _burstReceived = false;
  int _burstSeq = 0;
  int _seenChat = 0;

  @override
  void initState() {
    super.initState();
    // Warm the camera so the lobby shows you straight away.
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<MatchProvider>().ensureCamera());
  }

  @override
  void dispose() {
    _message.dispose();
    _chatScroll.dispose();
    super.dispose();
  }

  Future<void> _needCoins(String why) async {
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Not enough coins'),
        content: Text('$why\n\nTop up, or earn free coins in the store.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Not now')),
          TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Get coins')),
        ],
      ),
    );
    if (go == true && mounted) Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoreScreen(asPage: true)));
  }

  Future<void> _start() async {
    final m = context.read<MatchProvider>();
    if (!await m.start()) {
      final err = m.lastError;
      if (err != null && mounted) await _needCoins('These filters cost ${m.filterCost} coins per match.');
    }
  }

  Future<void> _next() async {
    final m = context.read<MatchProvider>();
    HapticFeedback.mediumImpact();
    if (m.inCooldown) {
      final pay = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Slow down a second'),
          content: Text('Five quick skips in a row. Wait ${m.cooldownSeconds}s, or skip now for ${Economy.skipCooldownBypassCost} coins.'),
          actions: [
            TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Wait')),
            TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: Text('Skip for ${Economy.skipCooldownBypassCost}')),
          ],
        ),
      );
      if (pay != true) return;
      if (!await m.bypassCooldown() && mounted) await _needCoins('Skipping the cooldown costs ${Economy.skipCooldownBypassCost} coins.');
      return;
    }
    if (!await m.next() && mounted && m.lastError != null) await _needCoins('These filters cost ${m.filterCost} coins per match.');
  }

  Future<void> _gift() async {
    final m = context.read<MatchProvider>();
    final p = m.partner;
    if (p == null) return;
    final g = await showGiftSheet(context, toName: p.name);
    if (g == null || !mounted) return;
    if (await m.sendGift(g)) {
      setState(() {
        _burst = g;
        _burstReceived = false;
        _burstSeq++;
      });
    } else if (mounted) {
      await _needCoins('A ${g.name} costs ${g.coins} coins.');
    }
  }

  Future<void> _addFriend() async {
    final m = context.read<MatchProvider>();
    final wallet = context.read<WalletProvider>();
    final free = wallet.freeFriendRequestsLeft;
    if (free == 0) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Send a friend request?'),
          content: Text('Your ${Economy.freeFriendRequestsPerDay} free requests for today are used. This one costs ${Economy.friendRequestCost} coins.'),
          actions: [
            TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
            TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: Text('Send for ${Economy.friendRequestCost}')),
          ],
        ),
      );
      if (ok != true) return;
    }
    if (!await m.addFriend() && mounted) {
      await _needCoins('A friend request costs ${Economy.friendRequestCost} coins once your free ones are used.');
    } else if (mounted) {
      toast(context, 'Request sent');
    }
  }

  Future<void> _report() async {
    final m = context.read<MatchProvider>();
    final p = m.partner;
    if (p == null) return;
    final choice = await showReportSheet(context, name: p.name);
    if (choice == null || !mounted) return;
    await m.report(choice.reason, note: choice.note, block: choice.block);
    if (mounted) toast(context, 'Thanks. ${p.name} was reported${choice.block ? ' and blocked' : ''}.');
  }

  Future<void> _reconnect() async {
    final m = context.read<MatchProvider>();
    if (!await m.reconnect() && mounted) await _needCoins('Reconnecting costs ${Economy.reconnectCost} coins.');
  }

  @override
  Widget build(BuildContext context) {
    final m = context.watch<MatchProvider>();
    // A new incoming gift → burst.
    if (m.chat.length > _seenChat) {
      final fresh = m.chat.skip(_seenChat).where((c) => !c.fromMe && c.gift != null).toList();
      _seenChat = m.chat.length;
      if (fresh.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            setState(() {
              _burst = fresh.last.gift;
              _burstReceived = true;
              _burstSeq++;
            });
          }
        });
      }
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_chatScroll.hasClients) _chatScroll.jumpTo(_chatScroll.position.maxScrollExtent);
      });
    }
    if (m.state == MatchState.idle || m.state == MatchState.ended) _seenChat = 0;

    return Scaffold(
      backgroundColor: V.bg,
      body: Stack(
        fit: StackFit.expand,
        children: [
          switch (m.state) {
            MatchState.connected => _Connected(m: m, onNext: _next, onGift: _gift, onAddFriend: _addFriend, onReport: _report, message: _message, chatScroll: _chatScroll),
            MatchState.searching => _Searching(m: m),
            _ => _Lobby(m: m, onStart: _start, onOpenStore: widget.onOpenStore, onReconnect: _reconnect),
          },
          if (_burst != null)
            Positioned.fill(
              child: IgnorePointer(
                child: Center(
                  child: GiftBurst(
                    key: ValueKey('${_burst!.id}-$_burstSeq'),
                    gift: _burst!,
                    received: _burstReceived,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ── lobby ──────────────────────────────────────────────────────────────

class _Lobby extends StatelessWidget {
  const _Lobby({required this.m, required this.onStart, required this.onOpenStore, required this.onReconnect});
  final MatchProvider m;
  final VoidCallback onStart;
  final VoidCallback onOpenStore;
  final VoidCallback onReconnect;

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();
    final me = context.watch<SessionProvider>().me;
    final ended = m.state == MatchState.ended;
    final cost = m.filterCost;
    return Stack(
      fit: StackFit.expand,
      children: [
        _SelfVideo(m: m, dim: 0.55),
        SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: Row(
                  children: [
                    if (me != null) VAvatar(url: me.avatarUrl, name: me.name, size: 36, ring: wallet.isVip),
                    const SizedBox(width: 10),
                    Expanded(child: Text(me == null ? 'Vibe' : 'Hi ${me.name.split(' ').first}', style: VT.title(16, color: Colors.white))),
                    if (wallet.isVip) const Padding(padding: EdgeInsets.only(right: 8), child: Tag('VIP', color: V.gold, icon: Icons.workspace_premium_rounded)),
                    CoinChip(coins: wallet.coins, onTap: onOpenStore),
                  ],
                ),
              ),
              const Spacer(),
              if (ended && m.lastPartner != null) _EndedCard(m: m, onReconnect: onReconnect, onFindAnother: onStart) else ...[
                PulseRings(
                  size: 230,
                  child: GestureDetector(
                    onTap: onStart,
                    child: Container(
                      width: 150,
                      height: 150,
                      decoration: BoxDecoration(shape: BoxShape.circle, gradient: V.brand, boxShadow: [BoxShadow(color: V.pink.withValues(alpha: 0.5), blurRadius: 40, spreadRadius: 4)]),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.videocam_rounded, size: 44, color: Colors.white),
                          const SizedBox(height: 4),
                          Text('Start', style: VT.title(18, color: Colors.white)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text('${_online()} people online now', style: VT.label(13, color: Colors.white.withValues(alpha: 0.8))),
              ],
              const Spacer(),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: _LobbyChip(
                            icon: Icons.tune_rounded,
                            label: _filterSummary(m.filters),
                            trailing: cost > 0 ? '$cost coins' : (wallet.isVip ? 'VIP' : 'free'),
                            trailingColor: cost > 0 ? V.gold : V.ok,
                            onTap: () => showFiltersSheet(context),
                          ),
                        ),
                        const SizedBox(width: 8),
                        _LobbyChip(
                          icon: Icons.bolt_rounded,
                          label: wallet.isBoosted ? Fmt.until(wallet.wallet.boostUntil!) : 'Boost',
                          trailing: wallet.isBoosted ? null : '${Economy.boostCost}',
                          trailingColor: V.gold,
                          active: wallet.isBoosted,
                          onTap: () async {
                            if (wallet.isBoosted) return;
                            final ok = await showDialog<bool>(
                              context: context,
                              builder: (ctx) => AlertDialog(
                                title: const Text('Boost for 30 minutes?'),
                                content: Text('You go to the front of the queue — faster matches, more of them. ${Economy.boostCost} coins.'),
                                actions: [
                                  TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Not now')),
                                  TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Boost')),
                                ],
                              ),
                            );
                            if (ok == true && !await wallet.boost() && context.mounted) {
                              toast(context, 'Not enough coins for a boost', error: true);
                            }
                          },
                        ),
                      ],
                    ),
                    if (m.lastError != null && !ended) ...[
                      const SizedBox(height: 10),
                      Glass(child: Row(children: [const Icon(Icons.error_outline_rounded, size: 16, color: V.bad), const SizedBox(width: 8), Expanded(child: Text(m.lastError!, style: VT.body(12, color: Colors.white)))])),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  static String _filterSummary(MatchFilters f) {
    final parts = <String>[
      switch (f.gender) { GenderFilter.anyone => 'Anyone', GenderFilter.women => 'Women', GenderFilter.men => 'Men' },
      f.countryCode ?? 'Anywhere',
    ];
    if (f.safeMode) parts.add('Verified only');
    return parts.join(' · ');
  }

  static int _online() {
    final h = DateTime.now().hour;
    final base = h >= 20 || h < 2 ? 2400 : h >= 12 ? 1500 : 700;
    return base + DateTime.now().minute * 7;
  }
}

class _LobbyChip extends StatelessWidget {
  const _LobbyChip({required this.icon, required this.label, this.trailing, this.trailingColor, required this.onTap, this.active = false});
  final IconData icon;
  final String label;
  final String? trailing;
  final Color? trailingColor;
  final VoidCallback onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Glass(
        radius: 22,
        opacity: active ? 0.05 : 0.25,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 18, color: active ? V.gold : Colors.white),
            const SizedBox(width: 8),
            Flexible(child: Text(label, overflow: TextOverflow.ellipsis, style: VT.title(13, weight: FontWeight.w600, color: Colors.white))),
            if (trailing != null) ...[
              const SizedBox(width: 8),
              Text(trailing!, style: VT.label(12, color: trailingColor ?? V.text2, weight: FontWeight.w800)),
            ],
          ],
        ),
      ),
    );
  }
}

class _EndedCard extends StatelessWidget {
  const _EndedCard({required this.m, required this.onReconnect, required this.onFindAnother});
  final MatchProvider m;
  final VoidCallback onReconnect;
  final VoidCallback onFindAnother;

  @override
  Widget build(BuildContext context) {
    final p = m.lastPartner!;
    final why = switch (m.endReason) {
      EndReason.partnerLeft => '${p.name} left',
      EndReason.skipped => 'You skipped ${p.name}',
      EndReason.reported => 'Reported and ended',
      _ => 'Call ended',
    };
    final last = m.history.isEmpty ? null : m.history.first;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Glass(
        radius: 24,
        opacity: 0.35,
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            VAvatar(url: p.avatarUrl, name: p.name, size: 72, ring: true),
            const SizedBox(height: 10),
            Text(why, style: VT.title(18, color: Colors.white)),
            const SizedBox(height: 4),
            Text(
              [if (last != null) Fmt.duration(last.length), if (last?.likedMe == true) '${p.name} liked you', if (last?.giftsReceived != null && last!.giftsReceived > 0) '${last.giftsReceived} gift(s) received'].join(' · '),
              style: VT.body(13, color: Colors.white.withValues(alpha: 0.75)),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            GradientButton(label: 'Find someone else', onTap: onFindAnother, icon: Icons.videocam_rounded, height: 50),
            if (m.endReason != EndReason.reported) ...[
              const SizedBox(height: 8),
              GhostButton(label: 'Reconnect with ${p.name} · ${Economy.reconnectCost} coins', icon: Icons.replay_rounded, expand: true, onTap: onReconnect),
            ],
            const SizedBox(height: 4),
            TextButton(onPressed: m.dismissEnded, child: Text('Close', style: VT.label(13, color: Colors.white70))),
          ],
        ),
      ),
    );
  }
}

// ── searching ──────────────────────────────────────────────────────────

class _Searching extends StatelessWidget {
  const _Searching({required this.m});
  final MatchProvider m;

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();
    return Stack(
      fit: StackFit.expand,
      children: [
        _SelfVideo(m: m, dim: 0.6),
        SafeArea(
          child: Column(
            children: [
              const Spacer(),
              PulseRings(
                size: 260,
                color: V.violet,
                child: Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.black.withValues(alpha: 0.35), border: Border.all(color: Colors.white24)),
                  child: const Icon(Icons.travel_explore_rounded, size: 48, color: Colors.white),
                ),
              ),
              const SizedBox(height: 8),
              Text(wallet.isBoosted ? 'Boosted · finding someone fast' : 'Finding someone for you…', style: VT.title(18, color: Colors.white)),
              const SizedBox(height: 6),
              Text(_Lobby._filterSummary(m.filters), style: VT.body(13, color: Colors.white70)),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.only(bottom: 32),
                child: GhostButton(label: 'Cancel', icon: Icons.close_rounded, onTap: m.stop),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ── connected ──────────────────────────────────────────────────────────

class _Connected extends StatelessWidget {
  const _Connected({required this.m, required this.onNext, required this.onGift, required this.onAddFriend, required this.onReport, required this.message, required this.chatScroll});
  final MatchProvider m;
  final VoidCallback onNext;
  final VoidCallback onGift;
  final VoidCallback onAddFriend;
  final VoidCallback onReport;
  final TextEditingController message;
  final ScrollController chatScroll;

  @override
  Widget build(BuildContext context) {
    final p = m.partner!;
    final friendState = m.friendState;
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    return Stack(
      fit: StackFit.expand,
      children: [
        _PartnerStage(partner: p, blurred: m.blurred),
        // Top: who, timer, report.
        SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Glass(
                    padding: const EdgeInsets.fromLTRB(8, 6, 12, 6),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        VAvatar(url: p.avatarUrl, name: p.name, size: 34),
                        const SizedBox(width: 10),
                        Flexible(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Flexible(child: Text('${p.name}, ${p.age}', overflow: TextOverflow.ellipsis, style: VT.title(15, color: Colors.white))),
                                  if (p.verified) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.verified_rounded, size: 15, color: V.gem)),
                                  if (p.vip) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.workspace_premium_rounded, size: 15, color: V.gold)),
                                ],
                              ),
                              Text('${p.country.flag} ${p.country.name} · ${Fmt.duration(m.elapsed)}', style: VT.label(11, color: Colors.white70)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                RoundControl(icon: Icons.flag_rounded, size: 40, onTap: onReport, background: Colors.black.withValues(alpha: 0.35)),
              ],
            ),
          ),
        ),
        // Self PiP
        Positioned(
          right: 12,
          top: MediaQuery.of(context).padding.top + 70,
          child: Container(
            width: 104,
            height: 150,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white24), color: V.surface2),
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (m.hasLocalVideo && m.camOn) RTCVideoView(m.localRenderer, mirror: m.frontCamera, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover) else const Center(child: Icon(Icons.videocam_off_rounded, color: V.muted)),
                if (m.blurred) BackdropFilter(filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12), child: const SizedBox.expand()),
              ],
            ),
          ),
        ),
        // Likes
        if (m.partnerLikedMe || m.likedPartner)
          Positioned(
            left: 12,
            top: MediaQuery.of(context).padding.top + 70,
            child: Glass(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              child: Text(m.mutualLike ? '💞 You both liked each other' : (m.partnerLikedMe ? '❤️ ${p.name} liked you' : '❤️ Liked'), style: VT.label(12, color: Colors.white)),
            ),
          ),
        // Bottom stack: chat, controls, composer
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          child: Container(
            decoration: const BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, Color(0xCC000000)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
            padding: EdgeInsets.only(bottom: bottomInset > 0 ? bottomInset + 8 : MediaQuery.of(context).padding.bottom + 8),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _ChatOverlay(m: m, controller: chatScroll),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      RoundControl(icon: m.likedPartner ? Icons.favorite_rounded : Icons.favorite_border_rounded, color: m.likedPartner ? V.pink : Colors.white, onTap: m.like, label: 'Like'),
                      RoundControl(icon: Icons.card_giftcard_rounded, onTap: onGift, label: 'Gift', color: V.gold),
                      _NextButton(m: m, onTap: onNext),
                      RoundControl(
                        icon: switch (friendState) { FriendState.friends => Icons.how_to_reg_rounded, FriendState.requested => Icons.hourglass_top_rounded, _ => Icons.person_add_alt_1_rounded },
                        onTap: friendState == FriendState.none || friendState == FriendState.incoming ? onAddFriend : null,
                        label: switch (friendState) { FriendState.friends => 'Friends', FriendState.requested => 'Sent', FriendState.incoming => 'Accept', _ => 'Add' },
                        color: friendState == FriendState.friends ? V.ok : Colors.white,
                      ),
                      RoundControl(icon: Icons.more_horiz_rounded, onTap: () => _more(context), label: 'More'),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      Expanded(
                        child: Glass(
                          radius: 24,
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
                          child: TextField(
                            controller: message,
                            style: VT.body(14, color: Colors.white),
                            textInputAction: TextInputAction.send,
                            decoration: InputDecoration(hintText: 'Say something…', hintStyle: VT.body(14, color: Colors.white54), filled: false, border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none, contentPadding: EdgeInsets.zero, isDense: true),
                            onSubmitted: (v) {
                              m.sendMessage(v);
                              message.clear();
                            },
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      RoundControl(
                        icon: Icons.send_rounded,
                        size: 44,
                        background: V.violet,
                        onTap: () {
                          m.sendMessage(message.text);
                          message.clear();
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _more(BuildContext context) {
    showVibeSheet(
      context,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(leading: Icon(m.micOn ? Icons.mic_rounded : Icons.mic_off_rounded), title: Text(m.micOn ? 'Mute microphone' : 'Unmute'), onTap: () { m.toggleMic(); Navigator.of(context).pop(); }),
            ListTile(leading: Icon(m.camOn ? Icons.videocam_rounded : Icons.videocam_off_rounded), title: Text(m.camOn ? 'Turn camera off' : 'Turn camera on'), onTap: () { m.toggleCam(); Navigator.of(context).pop(); }),
            ListTile(leading: const Icon(Icons.cameraswitch_rounded), title: const Text('Switch camera'), onTap: () { m.switchCamera(); Navigator.of(context).pop(); }),
            ListTile(leading: const Icon(Icons.block_rounded, color: V.bad), title: const Text('Block and end', style: TextStyle(color: V.bad)), onTap: () { m.blockPartner(); Navigator.of(context).pop(); }),
            ListTile(leading: const Icon(Icons.call_end_rounded), title: const Text('End and go back'), onTap: () { m.stop(); Navigator.of(context).pop(); }),
          ],
        ),
      ),
    );
  }
}

class _NextButton extends StatelessWidget {
  const _NextButton({required this.m, required this.onTap});
  final MatchProvider m;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cd = m.cooldownSeconds;
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(shape: BoxShape.circle, gradient: cd > 0 ? const LinearGradient(colors: [V.surface3, V.surface2]) : V.brand, boxShadow: [BoxShadow(color: (cd > 0 ? Colors.black : V.pink).withValues(alpha: 0.45), blurRadius: 24, offset: const Offset(0, 8))]),
            child: cd > 0
                ? Center(child: Text('${cd}s', style: VT.title(20, color: Colors.white)))
                : const Icon(Icons.skip_next_rounded, size: 38, color: Colors.white),
          ),
          const SizedBox(height: 6),
          Text(cd > 0 ? 'Skip · ${Economy.skipCooldownBypassCost}¢' : 'Next', style: VT.label(11, color: Colors.white.withValues(alpha: 0.85))),
        ],
      ),
    );
  }
}

class _ChatOverlay extends StatelessWidget {
  const _ChatOverlay({required this.m, required this.controller});
  final MatchProvider m;
  final ScrollController controller;

  @override
  Widget build(BuildContext context) {
    final items = m.chat;
    if (items.isEmpty) return const SizedBox(height: 8);
    return ConstrainedBox(
      constraints: const BoxConstraints(maxHeight: 132),
      child: ListView.builder(
        controller: controller,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        shrinkWrap: true,
        itemCount: items.length,
        itemBuilder: (context, i) {
          final c = items[i];
          return Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Glass(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                radius: 12,
                child: RichText(
                  text: TextSpan(
                    style: VT.body(13, color: Colors.white),
                    children: [
                      TextSpan(text: c.fromMe ? 'You  ' : '${m.partner?.name ?? 'Them'}  ', style: VT.label(12, color: c.fromMe ? V.gem : V.pink)),
                      TextSpan(text: c.gift != null ? '${c.gift!.emoji} ${c.text}' : c.text),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// The partner's "video": a mocked stage built from their portrait. When
/// WebRTC peers arrive this becomes an RTCVideoView, nothing else moves.
class _PartnerStage extends StatelessWidget {
  const _PartnerStage({required this.partner, required this.blurred});
  final Profile partner;
  final bool blurred;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Image.network(partner.avatarUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF2B1B4D), V.bg], begin: Alignment.topCenter, end: Alignment.bottomCenter)))),
        Container(color: Colors.black.withValues(alpha: 0.25)),
        Center(child: VAvatar(url: partner.avatarUrl, name: partner.name, size: 168, ring: true)),
        Positioned(
          bottom: 250,
          left: 0,
          right: 0,
          child: Center(child: Glass(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), child: Row(mainAxisSize: MainAxisSize.min, children: [Container(width: 8, height: 8, decoration: const BoxDecoration(shape: BoxShape.circle, color: V.bad)), const SizedBox(width: 6), Text('LIVE · mock video', style: VT.label(11, color: Colors.white))]))),
        ),
        if (blurred)
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
            child: Container(color: Colors.black.withValues(alpha: 0.1), alignment: Alignment.center, child: Glass(child: Text('Unblurring…', style: VT.label(12, color: Colors.white)))),
          ),
      ],
    );
  }
}

/// Your own camera as a full-bleed background (lobby, searching).
class _SelfVideo extends StatelessWidget {
  const _SelfVideo({required this.m, required this.dim});
  final MatchProvider m;
  final double dim;

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        if (m.hasLocalVideo && m.camOn)
          RTCVideoView(m.localRenderer, mirror: m.frontCamera, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)
        else
          Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF2A1440), V.bg], begin: Alignment.topCenter, end: Alignment.bottomCenter))),
        Container(color: Colors.black.withValues(alpha: dim)),
      ],
    );
  }
}

/// Small helper used by the lobby's VIP nudge.
class VipNudge extends StatelessWidget {
  const VipNudge({super.key});
  @override
  Widget build(BuildContext context) {
    return GhostButton(label: 'Get VIP', icon: Icons.workspace_premium_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VipScreen())));
  }
}
