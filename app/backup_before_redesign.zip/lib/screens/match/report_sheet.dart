import 'package:flutter/material.dart';

import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../../models/models.dart';

class ReportChoice {
  const ReportChoice(this.reason, this.block, this.note);
  final ReportReason reason;
  final bool block;
  final String? note;
}

/// Two taps to report: pick a reason, submit. Block is on by default —
/// nobody reports someone they want to meet again.
Future<ReportChoice?> showReportSheet(BuildContext context, {required String name}) {
  return showVibeSheet<ReportChoice>(context, scrollable: true, child: _ReportSheet(name: name));
}

class _ReportSheet extends StatefulWidget {
  const _ReportSheet({required this.name});
  final String name;

  @override
  State<_ReportSheet> createState() => _ReportSheetState();
}

class _ReportSheetState extends State<_ReportSheet> {
  ReportReason? _reason;
  bool _block = true;
  final _note = TextEditingController();

  @override
  void dispose() {
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Report ${widget.name}', style: VT.title(20)),
          const SizedBox(height: 4),
          Text('The match ends now. Our team reviews every report; three in a day removes the account.', style: VT.body(13, color: V.text2)),
          const SizedBox(height: 14),
          for (final r in ReportReason.values)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Panel(
                color: _reason == r ? V.pink.withValues(alpha: 0.14) : V.surface2,
                border: _reason == r ? V.pink : V.line,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
                onTap: () => setState(() => _reason = r),
                child: Row(
                  children: [
                    Icon(_reason == r ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, size: 20, color: _reason == r ? V.pink : V.muted),
                    const SizedBox(width: 12),
                    Expanded(child: Text(r.label, style: VT.body(15))),
                  ],
                ),
              ),
            ),
          if (_reason == ReportReason.other) TextField(controller: _note, maxLines: 2, decoration: const InputDecoration(hintText: 'What happened?')),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: Text('Also block ${widget.name}', style: VT.body(14))),
              Switch(value: _block, onChanged: (v) => setState(() => _block = v)),
            ],
          ),
          const SizedBox(height: 12),
          GradientButton(
            label: 'Submit report',
            gradient: const LinearGradient(colors: [V.bad, Color(0xFFE11D48)]),
            onTap: _reason == null ? null : () => Navigator.of(context).pop(ReportChoice(_reason!, _block, _note.text.trim().isEmpty ? null : _note.text.trim())),
          ),
        ],
      ),
    );
  }
}
