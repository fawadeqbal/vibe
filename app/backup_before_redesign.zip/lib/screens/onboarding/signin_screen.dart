import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../../providers/session_provider.dart';
import '../splash_screen.dart';

/// Phone first (the category's norm), social buttons under it. All mocked:
/// any number and any 4-digit code sign you in.
class SignInScreen extends StatefulWidget {
  const SignInScreen({super.key});

  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final _phone = TextEditingController();
  final _code = TextEditingController();
  bool _codeStep = false;
  String? _error;

  @override
  void dispose() {
    _phone.dispose();
    _code.dispose();
    super.dispose();
  }

  Future<void> _sendCode() async {
    final digits = _phone.text.replaceAll(RegExp(r'\D'), '');
    if (digits.length < 9) {
      setState(() => _error = 'Enter your full number, with the country code.');
      return;
    }
    setState(() {
      _error = null;
      _codeStep = true;
    });
  }

  Future<void> _verify() async {
    if (_code.text.trim().length != 4) {
      setState(() => _error = 'The code is 4 digits.');
      return;
    }
    setState(() => _error = null);
    await context.read<SessionProvider>().signIn(method: 'phone', phone: _phone.text.trim());
  }

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionProvider>();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Center(child: VibeMark(size: 48)),
              const SizedBox(height: 28),
              Text(_codeStep ? 'Enter the code' : 'Your number', style: VT.display(30)),
              const SizedBox(height: 8),
              Text(
                _codeStep ? 'We sent a 4-digit code to ${_phone.text}. (Mock: any 4 digits work.)' : 'We only use it to sign you in. Nobody on Vibe sees it.',
                style: VT.body(15, color: V.text2),
              ),
              const SizedBox(height: 28),
              if (!_codeStep)
                TextField(
                  controller: _phone,
                  keyboardType: TextInputType.phone,
                  autofocus: true,
                  style: VT.title(20, weight: FontWeight.w600),
                  decoration: const InputDecoration(hintText: '+92 3xx xxxxxxx', prefixIcon: Icon(Icons.phone_iphone_rounded, color: V.text2)),
                )
              else
                TextField(
                  controller: _code,
                  keyboardType: TextInputType.number,
                  autofocus: true,
                  maxLength: 4,
                  textAlign: TextAlign.center,
                  style: VT.display(30),
                  decoration: const InputDecoration(hintText: '••••', counterText: ''),
                  onSubmitted: (_) => _verify(),
                ),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(_error!, style: VT.body(13, color: V.bad)),
              ],
              const SizedBox(height: 20),
              GradientButton(label: _codeStep ? 'Verify and continue' : 'Send code', onTap: _codeStep ? _verify : _sendCode, busy: session.busy),
              if (_codeStep) ...[
                const SizedBox(height: 10),
                TextButton(onPressed: () => setState(() => _codeStep = false), child: Text('Change number', style: VT.label(14, color: V.text2))),
              ],
              const SizedBox(height: 28),
              Row(
                children: [
                  const Expanded(child: Divider(color: V.line)),
                  Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Text('or', style: VT.label(12, color: V.muted))),
                  const Expanded(child: Divider(color: V.line)),
                ],
              ),
              const SizedBox(height: 20),
              _social('Continue with Google', Icons.g_mobiledata_rounded, () => context.read<SessionProvider>().signIn(method: 'google'), session.busy),
              const SizedBox(height: 10),
              _social('Continue with Apple', Icons.apple, () => context.read<SessionProvider>().signIn(method: 'apple'), session.busy),
              const SizedBox(height: 24),
              Text('Mock sign-in: nothing is sent anywhere. Real OTP, Google and Apple sign-in are wired in when the backend arrives.', textAlign: TextAlign.center, style: VT.body(11, color: V.muted)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _social(String label, IconData icon, VoidCallback onTap, bool busy) {
    return Material(
      color: V.surface2,
      borderRadius: BorderRadius.circular(28),
      child: InkWell(
        borderRadius: BorderRadius.circular(28),
        onTap: busy ? null : onTap,
        child: SizedBox(
          height: 52,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: V.text, size: 26),
              const SizedBox(width: 8),
              Text(label, style: VT.title(15, weight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}
