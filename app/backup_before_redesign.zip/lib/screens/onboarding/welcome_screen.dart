import 'package:flutter/material.dart';

import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../splash_screen.dart';

/// First screen ever. One promise, one button.
class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key, required this.onContinue});
  final VoidCallback onContinue;

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  final _page = PageController();
  int _index = 0;

  static const _slides = <(String, String, IconData)>[
    ('Meet someone new,\nright now', 'One tap connects you on video with a real person somewhere in the world.', Icons.videocam_rounded),
    ('Swipe to the next', 'Not your vibe? Swipe. There is always someone else online.', Icons.swipe_rounded),
    ('Get paid to be you', 'People send gifts to the ones they enjoy talking to. Gifts become gems, gems become cash.', Icons.diamond_rounded),
  ];

  @override
  void dispose() {
    _page.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF1B0F2E), V.bg], begin: Alignment.topCenter, end: Alignment.center),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const VibeMark(size: 30),
                  const SizedBox(width: 10),
                  Text('Vibe', style: VT.title(22)),
                ],
              ),
              Expanded(
                child: PageView.builder(
                  controller: _page,
                  itemCount: _slides.length,
                  onPageChanged: (i) => setState(() => _index = i),
                  itemBuilder: (context, i) {
                    final (title, body, icon) = _slides[i];
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 120,
                            height: 120,
                            decoration: BoxDecoration(gradient: V.brand, borderRadius: BorderRadius.circular(40), boxShadow: [BoxShadow(color: V.violet.withValues(alpha: 0.45), blurRadius: 40, offset: const Offset(0, 16))]),
                            child: Icon(icon, size: 56, color: Colors.white),
                          ),
                          const SizedBox(height: 40),
                          Text(title, textAlign: TextAlign.center, style: VT.display(32)),
                          const SizedBox(height: 14),
                          Text(body, textAlign: TextAlign.center, style: VT.body(16, color: V.text2, height: 1.5)),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(_slides.length, (i) {
                  final on = i == _index;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: on ? 22 : 6,
                    height: 6,
                    decoration: BoxDecoration(color: on ? V.pink : V.lineStrong, borderRadius: BorderRadius.circular(3)),
                  );
                }),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 28, 24, 12),
                child: GradientButton(label: 'Get started', onTap: widget.onContinue, icon: Icons.arrow_forward_rounded),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(32, 0, 32, 16),
                child: Text('You must be 18 or older. By continuing you agree to the Terms and confirm you have read the Privacy Policy.', textAlign: TextAlign.center, style: VT.body(11, color: V.muted)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
