import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../../core/util/format.dart';
import '../../models/models.dart';
import '../../providers/match_provider.dart';
import '../../providers/session_provider.dart';
import '../../providers/social_provider.dart';
import '../../providers/wallet_provider.dart';
import '../onboarding/profile_setup_screen.dart';
import '../store/vip_screen.dart';
import '../store/wallet_screen.dart';

/// You: the card people see, your numbers, verification, settings.
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key, required this.onOpenStore});
  final VoidCallback onOpenStore;

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionProvider>();
    final wallet = context.watch<WalletProvider>();
    final match = context.watch<MatchProvider>();
    final social = context.watch<SocialProvider>();
    final me = session.me;
    if (me == null) return const SizedBox.shrink();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Me'),
        actions: [
          IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProfileSetupScreen(editing: true))), icon: const Icon(Icons.edit_rounded)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
        children: [
          Row(
            children: [
              VAvatar(url: me.avatarUrl, name: me.name, size: 84, ring: wallet.isVip),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Flexible(child: Text('${me.name}, ${me.age}', style: VT.display(24), overflow: TextOverflow.ellipsis)),
                        if (me.verified) const Padding(padding: EdgeInsets.only(left: 6), child: Icon(Icons.verified_rounded, color: V.gem, size: 20)),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text('${me.country.flag} ${me.country.name} · ${me.gender.label}', style: VT.body(13, color: V.text2)),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        if (wallet.isVip) const Tag('VIP', color: V.gold, icon: Icons.workspace_premium_rounded),
                        if (!me.isComplete) const Tag('Profile incomplete', color: V.warn),
                        for (final i in me.interests.take(3)) Tag(i, color: V.violet),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (me.bio.trim().isNotEmpty) ...[const SizedBox(height: 12), Text(me.bio, style: VT.body(14, color: V.text2))],
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(child: _stat('Matches', Fmt.thousands(me.matches))),
              const SizedBox(width: 8),
              Expanded(child: _stat('Likes', Fmt.thousands(me.likes))),
              const SizedBox(width: 8),
              Expanded(child: _stat('Friends', Fmt.thousands(social.friends.length))),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _stat('Today', '${match.matchesToday} matches')),
              const SizedBox(width: 8),
              Expanded(child: _stat('Avg length', Fmt.duration(match.averageLength))),
              const SizedBox(width: 8),
              Expanded(child: _stat('Skip rate', '${(match.skipRate * 100).round()}%')),
            ],
          ),
          const SectionTitle('Wallet'),
          Panel(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const WalletScreen())),
            child: Row(
              children: [
                Expanded(child: Row(children: [const CoinIcon(size: 22), const SizedBox(width: 8), Text(Fmt.thousands(wallet.coins), style: VT.title(18, color: V.gold)), const SizedBox(width: 6), Text('coins', style: VT.body(12, color: V.text2))])),
                Expanded(child: Row(children: [const GemIcon(size: 22), const SizedBox(width: 8), Text(Fmt.thousands(wallet.gems), style: VT.title(18, color: V.gem)), const SizedBox(width: 6), Text('gems', style: VT.body(12, color: V.text2))])),
                const Icon(Icons.chevron_right_rounded, color: V.muted),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Panel(
            gradient: wallet.isVip ? const LinearGradient(colors: [Color(0xFF3A2A08), Color(0xFF1A1724)]) : V.brandSoft,
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VipScreen())),
            child: Row(
              children: [
                const Icon(Icons.workspace_premium_rounded, color: V.gold),
                const SizedBox(width: 12),
                Expanded(child: Text(wallet.isVip ? 'VIP · ${Fmt.until(wallet.wallet.vipUntil!)}' : 'Get VIP — free filters, no ads, see who liked you', style: VT.body(14, weight: FontWeight.w600))),
                const Icon(Icons.chevron_right_rounded, color: V.muted),
              ],
            ),
          ),
          const SectionTitle('Trust'),
          Panel(
            child: Row(
              children: [
                Icon(me.verified ? Icons.verified_rounded : Icons.verified_outlined, color: me.verified ? V.gem : V.text2),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(me.verified ? 'Verified profile' : 'Verify your profile', style: VT.title(15, weight: FontWeight.w600)), Text(me.verified ? 'People in safe mode can match with you.' : 'A quick selfie check. Verified profiles get more matches and can be found in safe mode.', style: VT.body(12, color: V.text2))])),
                if (!me.verified)
                  TextButton(
                    onPressed: session.busy
                        ? null
                        : () async {
                            final ok = await session.verifySelfie();
                            if (context.mounted) toast(context, ok ? 'Verified — badge added' : 'Could not verify, try again', error: !ok);
                          },
                    child: session.busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : Text('Verify', style: VT.label(13, color: V.pink)),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Panel(
            padding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
            child: Row(
              children: [
                const Icon(Icons.blur_on_rounded, color: V.text2),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Blur the first 3 seconds', style: VT.title(15, weight: FontWeight.w600)), Text('Both videos start blurred.', style: VT.body(12, color: V.text2))])),
                Switch(value: match.autoBlur, onChanged: match.setAutoBlur),
              ],
            ),
          ),
          if (social.blocked.isNotEmpty) ...[
            const SizedBox(height: 8),
            Panel(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  const Icon(Icons.block_rounded, color: V.text2),
                  const SizedBox(width: 12),
                  Expanded(child: Text('${social.blocked.length} blocked', style: VT.title(15, weight: FontWeight.w600))),
                  TextButton(
                    onPressed: () async {
                      for (final id in social.blocked.toList()) {
                        await social.unblock(id);
                      }
                      if (context.mounted) toast(context, 'Everyone unblocked');
                    },
                    child: Text('Unblock all', style: VT.label(13, color: V.pink)),
                  ),
                ],
              ),
            ),
          ],
          const SectionTitle('Recent matches'),
          if (match.history.isEmpty)
            Padding(padding: const EdgeInsets.all(8), child: Text('Your last matches will show up here.', style: VT.body(13, color: V.text2)))
          else
            for (final r in match.history.take(8)) _matchRow(r),
          const SectionTitle('Account'),
          Panel(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                ListTile(leading: const Icon(Icons.description_outlined, color: V.text2), title: const Text('Terms and privacy'), trailing: const Icon(Icons.chevron_right_rounded, color: V.muted), onTap: () => toast(context, 'Opens the policy pages in the real app')),
                const Divider(height: 1),
                ListTile(leading: const Icon(Icons.support_agent_rounded, color: V.text2), title: const Text('Help and safety'), trailing: const Icon(Icons.chevron_right_rounded, color: V.muted), onTap: () => toast(context, 'Opens the help centre in the real app')),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.logout_rounded, color: V.bad),
                  title: const Text('Sign out and reset the demo', style: TextStyle(color: V.bad)),
                  onTap: () async {
                    final ok = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: const Text('Sign out?'),
                        content: const Text('This mock build clears everything: coins, friends, history.'),
                        actions: [TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Sign out'))],
                      ),
                    );
                    if (ok == true) {
                      await match.releaseCamera();
                      await session.signOut();
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Center(child: Text('Vibe 0.1 · mock build', style: VT.body(11, color: V.muted))),
        ],
      ),
    );
  }

  Widget _stat(String label, String value) {
    return Panel(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: VT.label(11, color: V.muted)), const SizedBox(height: 2), Text(value, style: VT.title(16))]),
    );
  }

  Widget _matchRow(MatchRecord r) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Panel(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            VAvatar(url: r.partner.avatarUrl, name: r.partner.name, size: 40),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${r.partner.name}, ${r.partner.age} ${r.partner.country.flag}', style: VT.title(14, weight: FontWeight.w600)),
                  Text('${Fmt.duration(r.length)} · ${Fmt.ago(r.startedAt)}${r.likedMe ? ' · liked you' : ''}${r.giftsReceived > 0 ? ' · ${r.giftsReceived} gift(s)' : ''}', style: VT.body(12, color: V.text2)),
                ],
              ),
            ),
            if (r.liked) const Icon(Icons.favorite_rounded, size: 18, color: V.pink),
          ],
        ),
      ),
    );
  }
}
