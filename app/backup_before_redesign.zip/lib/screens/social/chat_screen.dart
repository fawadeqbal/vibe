import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../../core/util/format.dart';
import '../../providers/social_provider.dart';
import '../match/gift_sheet.dart';
import '../store/store_screen.dart';

/// Text chat with a friend. Gifts here earn them gems too — that is what
/// keeps friends on the app between matches.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.friendId});
  final String friendId;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  final _scroll = ScrollController();

  @override
  void dispose() {
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _send() {
    final social = context.read<SocialProvider>();
    social.sendMessage(widget.friendId, _text.text);
    _text.clear();
    _toBottom();
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
    });
  }

  Future<void> _gift(String name) async {
    final social = context.read<SocialProvider>();
    final g = await showGiftSheet(context, toName: name);
    if (g == null || !mounted) return;
    if (!await social.sendGift(widget.friendId, g) && mounted) {
      final go = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Not enough coins'),
          content: Text('A ${g.name} costs ${g.coins} coins.'),
          actions: [TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Not now')), TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Get coins'))],
        ),
      );
      if (go == true && mounted) Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoreScreen(asPage: true)));
    }
    _toBottom();
  }

  @override
  Widget build(BuildContext context) {
    final social = context.watch<SocialProvider>();
    final f = social.friend(widget.friendId);
    if (f == null) {
      return Scaffold(appBar: AppBar(), body: const EmptyState(icon: Icons.person_off_rounded, title: 'Not friends any more', body: 'This conversation is gone.'));
    }
    final msgs = social.messages(widget.friendId);
    // After the frame: markRead notifies listeners, which must not happen
    // during build.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<SocialProvider>().markRead(widget.friendId);
    });
    _toBottom();
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(
          children: [
            VAvatar(url: f.profile.avatarUrl, name: f.profile.name, size: 36),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(f.profile.name, style: VT.title(16)),
                  Text(f.online ? 'Online' : 'Last seen ${Fmt.ago(f.since)}', style: VT.label(11, color: f.online ? V.ok : V.muted)),
                ],
              ),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            color: V.surface2,
            onSelected: (v) async {
              if (v == 'remove') {
                await social.remove(widget.friendId);
              } else if (v == 'block') {
                await social.block(f.profile);
              }
              if (context.mounted) Navigator.of(context).pop();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'remove', child: Text('Remove friend')),
              PopupMenuItem(value: 'block', child: Text('Block', style: TextStyle(color: V.bad))),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: msgs.isEmpty
                ? EmptyState(icon: Icons.waving_hand_rounded, title: 'Say hi to ${f.profile.name}', body: 'You met in a match. ${f.profile.bio}')
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                    itemCount: msgs.length,
                    itemBuilder: (context, i) {
                      final m = msgs[i];
                      final mine = m.fromMe;
                      return Align(
                        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 6),
                          padding: EdgeInsets.symmetric(horizontal: m.gift != null ? 14 : 12, vertical: m.gift != null ? 10 : 8),
                          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
                          decoration: BoxDecoration(
                            gradient: mine && m.gift == null ? V.brand : null,
                            color: m.gift != null ? V.gold.withValues(alpha: 0.16) : (mine ? null : V.surface2),
                            borderRadius: BorderRadius.only(topLeft: const Radius.circular(18), topRight: const Radius.circular(18), bottomLeft: Radius.circular(mine ? 18 : 4), bottomRight: Radius.circular(mine ? 4 : 18)),
                            border: m.gift != null ? Border.all(color: V.gold.withValues(alpha: 0.5)) : null,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (m.gift != null) Text(m.gift!.emoji, style: const TextStyle(fontSize: 30)),
                              Text(m.text, style: VT.body(15, color: mine && m.gift == null ? Colors.white : V.text)),
                              const SizedBox(height: 2),
                              Text(Fmt.time(m.at), style: VT.label(10, color: mine && m.gift == null ? Colors.white70 : V.muted)),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
              child: Row(
                children: [
                  RoundControl(icon: Icons.card_giftcard_rounded, size: 44, color: V.gold, background: V.gold.withValues(alpha: 0.14), onTap: () => _gift(f.profile.name)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _text,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _send(),
                      decoration: const InputDecoration(hintText: 'Message'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  RoundControl(icon: Icons.send_rounded, size: 44, background: V.violet, onTap: _send),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
