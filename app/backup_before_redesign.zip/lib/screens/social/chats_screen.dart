import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../../core/util/format.dart';
import '../../models/models.dart';
import '../../providers/social_provider.dart';
import '../../providers/wallet_provider.dart';
import '../store/vip_screen.dart';
import 'chat_screen.dart';

/// Friends you made in matches. Requests on top, "liked you" teaser for
/// free users, then the conversation list.
class ChatsScreen extends StatelessWidget {
  const ChatsScreen({super.key, required this.onFindPeople});
  final VoidCallback onFindPeople;

  @override
  Widget build(BuildContext context) {
    final social = context.watch<SocialProvider>();
    final wallet = context.watch<WalletProvider>();
    final friends = social.friends;
    final incoming = social.incoming;
    final requested = social.requested;
    return Scaffold(
      appBar: AppBar(title: const Text('Chats')),
      body: friends.isEmpty && incoming.isEmpty && requested.isEmpty
          ? EmptyState(
              icon: Icons.chat_bubble_outline_rounded,
              title: 'No friends yet',
              body: 'Tap Add during a match. When they accept, you can keep talking here — text and gifts, any time.',
              action: GradientButton(label: 'Find people', icon: Icons.videocam_rounded, expand: false, onTap: onFindPeople),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
              children: [
                if (incoming.isNotEmpty) ...[
                  const SectionTitle('Requests'),
                  for (final f in incoming) _RequestTile(f: f),
                ],
                if (!wallet.isVip && social.likedYou.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Panel(
                      gradient: V.brandSoft,
                      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VipScreen())),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      child: Row(
                        children: [
                          SizedBox(
                            width: 64,
                            height: 32,
                            child: Stack(
                              children: [
                                for (var i = 0; i < 3 && i < social.likedYou.length; i++)
                                  Positioned(left: i * 16.0, child: VAvatar(url: social.likedYou[i].avatarUrl, name: social.likedYou[i].name, size: 32)),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(child: Text('${social.likedYou.length} people liked you. See who with VIP.', style: VT.body(13))),
                          const Icon(Icons.chevron_right_rounded, color: V.muted),
                        ],
                      ),
                    ),
                  ),
                if (requested.isNotEmpty) ...[
                  const SectionTitle('Sent'),
                  for (final f in requested)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Panel(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        child: Row(children: [VAvatar(url: f.profile.avatarUrl, name: f.profile.name, size: 40), const SizedBox(width: 12), Expanded(child: Text(f.profile.name, style: VT.title(15, weight: FontWeight.w600))), Text('Waiting…', style: VT.label(12, color: V.muted))]),
                      ),
                    ),
                ],
                const SectionTitle('Friends'),
                if (friends.isEmpty) Padding(padding: const EdgeInsets.all(8), child: Text('Nobody has accepted yet.', style: VT.body(13, color: V.text2))),
                for (final f in friends) _FriendTile(f: f),
              ],
            ),
    );
  }
}

class _RequestTile extends StatelessWidget {
  const _RequestTile({required this.f});
  final Friend f;

  @override
  Widget build(BuildContext context) {
    final social = context.read<SocialProvider>();
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Panel(
        border: V.pink.withValues(alpha: 0.4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          children: [
            VAvatar(url: f.profile.avatarUrl, name: f.profile.name, size: 44, ring: true),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${f.profile.name}, ${f.profile.age}', style: VT.title(15, weight: FontWeight.w600)), Text('${f.profile.country.flag} wants to be friends', style: VT.body(12, color: V.text2))])),
            IconButton(onPressed: () => social.decline(f.profile.id), icon: const Icon(Icons.close_rounded, color: V.muted)),
            Container(
              decoration: const BoxDecoration(shape: BoxShape.circle, gradient: V.brand),
              child: IconButton(onPressed: () => social.accept(f.profile.id), icon: const Icon(Icons.check_rounded, color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}

class _FriendTile extends StatelessWidget {
  const _FriendTile({required this.f});
  final Friend f;

  @override
  Widget build(BuildContext context) {
    final social = context.read<SocialProvider>();
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Panel(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        onTap: () {
          social.markRead(f.profile.id);
          Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(friendId: f.profile.id)));
        },
        child: Row(
          children: [
            Stack(
              children: [
                VAvatar(url: f.profile.avatarUrl, name: f.profile.name, size: 48),
                if (f.online) Positioned(right: 1, bottom: 1, child: Container(width: 12, height: 12, decoration: BoxDecoration(shape: BoxShape.circle, color: V.ok, border: Border.all(color: V.surface, width: 2)))),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text(f.profile.name, style: VT.title(15, weight: FontWeight.w600), overflow: TextOverflow.ellipsis)),
                      Text(f.lastMessage == null ? Fmt.ago(f.since) : Fmt.ago(social.messages(f.profile.id).isEmpty ? f.since : social.messages(f.profile.id).last.at), style: VT.label(11, color: V.muted)),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Expanded(child: Text(f.lastMessage ?? 'Say hi 👋', style: VT.body(13, color: f.unread > 0 ? V.text : V.text2), overflow: TextOverflow.ellipsis)),
                      if (f.unread > 0)
                        Container(
                          margin: const EdgeInsets.only(left: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(color: V.pink, borderRadius: BorderRadius.circular(10)),
                          child: Text('${f.unread}', style: VT.label(11, color: Colors.white, weight: FontWeight.w800)),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
