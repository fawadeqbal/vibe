import 'package:flutter/material.dart';

import '../core/theme/vibe_theme.dart';
import '../core/theme/vibe_widgets.dart';

/// The brand mark: two rings meeting — two people, one call.
class VibeMark extends StatelessWidget {
  const VibeMark({super.key, this.size = 72});
  final double size;

  @override
  Widget build(BuildContext context) {
    final ring = size * 0.62;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            left: size * 0.06,
            child: Container(width: ring, height: ring, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: V.pink, width: size * 0.09))),
          ),
          Positioned(
            right: size * 0.06,
            child: Container(width: ring, height: ring, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: V.violet, width: size * 0.09))),
          ),
        ],
      ),
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: V.bg,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const PulseRings(size: 200, child: VibeMark(size: 84)),
            const SizedBox(height: 8),
            Text('Vibe', style: VT.display(34)),
            const SizedBox(height: 6),
            Text('meet someone new', style: VT.body(14, color: V.text2)),
          ],
        ),
      ),
    );
  }
}
