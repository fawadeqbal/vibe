import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/mock/mock_backend.dart';
import '../../core/mock/mock_data.dart';
import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../../core/util/format.dart';
import '../../models/models.dart';
import '../../providers/session_provider.dart';
import '../../providers/wallet_provider.dart';
import 'checkout_screen.dart';
import 'vip_screen.dart';
import 'wallet_screen.dart';

/// Coins to buy, VIP to subscribe to, and free coins to earn — in that
/// order, because that is the order of revenue.
class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key, this.asPage = false});

  /// Pushed as a route (from a "not enough coins" prompt) rather than a tab.
  final bool asPage;

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Store'),
        automaticallyImplyLeading: asPage,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Row(
              children: [
                Icon(Icons.diamond_rounded, size: 16, color: V.gem),
                const SizedBox(width: 4),
                Text(Fmt.coins(wallet.gems), style: VT.label(13, color: V.gem, weight: FontWeight.w800)),
                const SizedBox(width: 10),
                CoinChip(coins: wallet.coins, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const WalletScreen()))),
              ],
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
        children: [
          if (!wallet.isVip) const _VipBanner(),
          const SectionTitle('Coins'),
          for (final p in MockData.packs) ...[_PackTile(pack: p), const SizedBox(height: 8)],
          const SectionTitle('Free coins'),
          const _EarnSection(),
          const SizedBox(height: 16),
          Text('Coins never expire. Prices are shown in USD; local methods charge the PKR equivalent.', style: VT.body(11, color: V.muted), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _VipBanner extends StatelessWidget {
  const _VipBanner();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Panel(
        gradient: const LinearGradient(colors: [Color(0xFF3B2A6D), Color(0xFF2A1440)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        border: V.violet.withValues(alpha: 0.5),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VipScreen())),
        child: Row(
          children: [
            Container(width: 48, height: 48, decoration: BoxDecoration(gradient: V.goldGrad, borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.workspace_premium_rounded, color: Colors.white)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Go VIP', style: VT.title(16)),
                  Text('Free filters, no ads, ${Economy.vipMonthlyBonusCoins} coins a month, see who liked you.', style: VT.body(12, color: V.text2)),
                ],
              ),
            ),
            Text('from ${Fmt.usd(MockData.plans.first.usd)}', style: VT.label(12, color: V.gold)),
          ],
        ),
      ),
    );
  }
}

class _PackTile extends StatelessWidget {
  const _PackTile({required this.pack});
  final CoinPack pack;

  @override
  Widget build(BuildContext context) {
    final best = pack.tag == 'Best value';
    return Panel(
      border: best ? V.gold.withValues(alpha: 0.6) : V.line,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CheckoutScreen(pack: pack))),
      child: Row(
        children: [
          const CoinIcon(size: 34),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(Fmt.coins(pack.coins), style: VT.title(18)),
                    if (pack.bonusPercent > 0) ...[const SizedBox(width: 6), Tag('+${pack.bonusPercent}% bonus', color: V.ok)],
                    if (pack.tag != null) ...[const SizedBox(width: 6), Tag(pack.tag!, color: best ? V.gold : V.pink)],
                  ],
                ),
                Text('${pack.name} · ${Fmt.usd(pack.usdPer100)} per 100', style: VT.body(12, color: V.text2)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(gradient: best ? V.goldGrad : null, color: best ? null : V.surface3, borderRadius: BorderRadius.circular(20)),
            child: Text(Fmt.usd(pack.usd), style: VT.title(14, color: best ? Colors.black : V.text)),
          ),
        ],
      ),
    );
  }
}

/// Daily check-in, rewarded ads, invite, profile bonus.
class _EarnSection extends StatefulWidget {
  const _EarnSection();

  @override
  State<_EarnSection> createState() => _EarnSectionState();
}

class _EarnSectionState extends State<_EarnSection> {
  bool _adBusy = false;

  Future<void> _checkIn() async {
    final wallet = context.read<WalletProvider>();
    final r = await wallet.checkIn();
    if (!mounted) return;
    toast(context, r == null ? 'Already checked in today' : '+$r coins · see you tomorrow', error: r == null);
  }

  Future<void> _watchAd() async {
    final wallet = context.read<WalletProvider>();
    if (wallet.adsLeftToday <= 0) {
      toast(context, 'You have watched all of today\'s ads', error: true);
      return;
    }
    setState(() => _adBusy = true);
    final filled = await context.read<MockBackend>().loadRewardedAd();
    if (!mounted) return;
    setState(() => _adBusy = false);
    if (!filled) {
      toast(context, 'No ad available right now. Try again in a minute.', error: true);
      return;
    }
    final watched = await showDialog<bool>(context: context, barrierDismissible: false, builder: (_) => const _MockAd());
    if (watched != true || !mounted) return;
    final r = await wallet.rewardAd();
    if (mounted) toast(context, r == null ? 'Daily ad limit reached' : '+$r coins', error: r == null);
  }

  Future<void> _invite() async {
    final wallet = context.read<WalletProvider>();
    // The real one shares a link and pays out when the friend signs up.
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Invite a friend'),
        content: Text('Share your link. When they finish setting up their profile you get ${Economy.inviteRewardCoins} coins.\n\nvibe.app/i/${wallet.hashCode.toRadixString(36)}\n\n(Mock: pretend a friend just joined.)'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Close')),
          TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Friend joined')),
        ],
      ),
    );
    if (ok == true) {
      final r = await wallet.claimInvite('a friend');
      if (mounted) toast(context, '+$r coins for the invite');
    }
  }

  Future<void> _profileBonus() async {
    final session = context.read<SessionProvider>();
    final wallet = context.read<WalletProvider>();
    if (session.me?.isComplete != true) {
      toast(context, 'Add a photo, a bio and 3 interests first', error: true);
      return;
    }
    final r = await wallet.claimProfileBonus();
    if (mounted) toast(context, r == null ? 'Already claimed' : '+$r coins', error: r == null);
  }

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();
    final me = context.watch<SessionProvider>().me;
    final day = wallet.nextCheckInDay;
    return Column(
      children: [
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: Text('Daily check-in', style: VT.title(15))),
                  Text(wallet.checkedInToday ? 'Done for today' : 'Day ${day + 1}', style: VT.label(12, color: wallet.checkedInToday ? V.ok : V.text2)),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  for (var i = 0; i < Economy.checkInRewards.length; i++) ...[
                    Expanded(
                      child: Container(
                        height: 46,
                        decoration: BoxDecoration(
                          gradient: i == day && !wallet.checkedInToday ? V.brand : null,
                          color: i < day || (i == day && wallet.checkedInToday) ? V.gold.withValues(alpha: 0.18) : (i == day ? null : V.surface2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('${Economy.checkInRewards[i]}', style: VT.label(12, color: i <= day ? V.gold : V.muted, weight: FontWeight.w800)),
                            Text(i == 6 ? '7' : '${i + 1}', style: VT.label(9, color: V.muted)),
                          ],
                        ),
                      ),
                    ),
                    if (i < 6) const SizedBox(width: 4),
                  ],
                ],
              ),
              const SizedBox(height: 12),
              GradientButton(label: wallet.checkedInToday ? 'Come back tomorrow' : 'Claim ${Economy.checkInRewards[day]} coins', onTap: wallet.checkedInToday ? null : _checkIn, height: 46),
            ],
          ),
        ),
        const SizedBox(height: 8),
        _earnRow(Icons.play_circle_fill_rounded, 'Watch an ad', '+${Economy.rewardedAdCoins} coins · ${wallet.adsLeftToday} left today', wallet.isVip ? 'VIP has no ads — but you can still earn' : null, _adBusy ? null : _watchAd, busy: _adBusy),
        const SizedBox(height: 8),
        _earnRow(Icons.person_add_alt_1_rounded, 'Invite a friend', '+${Economy.inviteRewardCoins} coins each', null, _invite),
        const SizedBox(height: 8),
        _earnRow(
          Icons.badge_rounded,
          'Complete your profile',
          wallet.wallet.profileBonusClaimed ? 'Claimed' : '+${Economy.profileCompleteCoins} coins once · ${me?.isComplete == true ? 'ready to claim' : 'photo, bio, 3 interests'}',
          null,
          wallet.wallet.profileBonusClaimed ? null : _profileBonus,
        ),
      ],
    );
  }

  Widget _earnRow(IconData icon, String title, String sub, String? note, VoidCallback? onTap, {bool busy = false}) {
    return Panel(
      onTap: onTap,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(width: 42, height: 42, decoration: BoxDecoration(color: V.gold.withValues(alpha: 0.14), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: V.gold)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: VT.title(15, weight: FontWeight.w600)),
                Text(sub, style: VT.body(12, color: V.text2)),
                if (note != null) Text(note, style: VT.body(11, color: V.muted)),
              ],
            ),
          ),
          if (busy) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: V.gold)) else Icon(Icons.chevron_right_rounded, color: onTap == null ? V.line : V.muted),
        ],
      ),
    );
  }
}

/// A 5-second "video ad" with a skip lock, the way rewarded ads behave.
class _MockAd extends StatefulWidget {
  const _MockAd();

  @override
  State<_MockAd> createState() => _MockAdState();
}

class _MockAdState extends State<_MockAd> {
  int _left = 5;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() => _left--);
      if (_left <= 0) t.cancel();
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.black,
      insetPadding: const EdgeInsets.all(16),
      child: AspectRatio(
        aspectRatio: 9 / 14,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF3A1D70), Color(0xFF0B0A10)], begin: Alignment.topLeft, end: Alignment.bottomRight))),
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.local_pizza_rounded, size: 72, color: V.gold),
                  const SizedBox(height: 12),
                  Text('Mock advertiser', style: VT.title(20, color: Colors.white)),
                  Text('A real rewarded ad plays here (AdMob).', style: VT.body(13, color: Colors.white70)),
                ],
              ),
            ),
            Positioned(
              top: 12,
              right: 12,
              child: Glass(
                child: _left > 0 ? Text('Reward in ${_left}s', style: VT.label(12, color: Colors.white)) : GestureDetector(onTap: () => Navigator.of(context).pop(true), child: Text('Claim reward ✓', style: VT.label(12, color: V.gold))),
              ),
            ),
            Positioned(bottom: 12, left: 12, child: Glass(child: Text('Ad', style: VT.label(10, color: Colors.white70)))),
          ],
        ),
      ),
    );
  }
}
