import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/mock/mock_data.dart';
import '../../core/theme/vibe_theme.dart';
import '../../core/theme/vibe_widgets.dart';
import '../../core/util/format.dart';
import '../../models/models.dart';
import '../../providers/social_provider.dart';
import '../../providers/wallet_provider.dart';
import 'checkout_screen.dart';

/// The subscription page: what VIP unlocks, three plans, a "who liked you"
/// teaser that is blurred until you pay.
class VipScreen extends StatefulWidget {
  const VipScreen({super.key});

  @override
  State<VipScreen> createState() => _VipScreenState();
}

class _VipScreenState extends State<VipScreen> {
  VipPlan _plan = MockData.plans[1];

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>();
    final liked = context.watch<SocialProvider>().likedYou;
    return Scaffold(
      appBar: AppBar(title: const Text('VIP')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF3B2A6D), Color(0xFF2A1440)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(V.rLg), border: Border.all(color: V.violet.withValues(alpha: 0.5))),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [const Icon(Icons.workspace_premium_rounded, color: V.gold, size: 28), const SizedBox(width: 8), Text('Vibe VIP', style: VT.display(26))]),
                const SizedBox(height: 4),
                Text(wallet.isVip ? 'Active · ${Fmt.until(wallet.wallet.vipUntil!)}' : 'Everything the free app holds back.', style: VT.body(14, color: V.text2)),
                const SizedBox(height: 16),
                for (final (icon, title, sub) in const [
                  (Icons.tune_rounded, 'Unlimited filters', 'Gender and country filters cost nothing.'),
                  (Icons.block_rounded, 'No ads', 'Never watch one again.'),
                  (Icons.favorite_rounded, 'See who liked you', 'Reconnect with people who wanted more.'),
                  (Icons.bolt_rounded, 'Priority matching', 'You go first in the queue, every time.'),
                  (Icons.monetization_on_rounded, '200 bonus coins a month', 'Landed on the day you subscribe.'),
                  (Icons.verified_rounded, 'VIP badge', 'People see it on the match screen.'),
                ])
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Row(
                      children: [
                        Icon(icon, size: 20, color: V.gold),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: VT.title(14, weight: FontWeight.w600)), Text(sub, style: VT.body(12, color: V.text2))])),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          const SectionTitle('Who liked you'),
          SizedBox(
            height: 92,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: liked.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (context, i) {
                final p = liked[i];
                return Column(
                  children: [
                    if (wallet.isVip)
                      VAvatar(url: p.avatarUrl, name: p.name, size: 64, ring: true)
                    else
                      ClipOval(
                        child: ImageFiltered(
                          imageFilter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                          child: VAvatar(url: p.avatarUrl, name: p.name, size: 64, ring: true),
                        ),
                      ),
                    const SizedBox(height: 6),
                    Text(wallet.isVip ? p.name : '•••••', style: VT.label(12)),
                  ],
                );
              },
            ),
          ),
          if (!wallet.isVip) ...[
            const SizedBox(height: 6),
            Text('${liked.length} people liked you this week. VIP shows who.', style: VT.body(13, color: V.text2), textAlign: TextAlign.center),
          ],
          const SectionTitle('Choose a plan'),
          Row(
            children: [
              for (final p in MockData.plans) ...[
                Expanded(child: _planCard(p)),
                if (p != MockData.plans.last) const SizedBox(width: 8),
              ],
            ],
          ),
          const SizedBox(height: 18),
          if (wallet.isVip)
            GhostButton(label: 'Cancel VIP', expand: true, color: V.bad, onTap: () async {
              await wallet.cancelVip();
              if (context.mounted) toast(context, 'VIP cancelled');
            })
          else
            GradientButton(
              label: _plan.trialDays > 0 ? 'Start ${_plan.trialDays}-day free trial' : 'Subscribe · ${Fmt.usd(_plan.usd)}',
              icon: Icons.workspace_premium_rounded,
              gradient: V.goldGrad,
              foreground: Colors.black,
              onTap: () async {
                final ok = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => CheckoutScreen(plan: _plan)));
                if (ok == true && context.mounted) Navigator.of(context).pop();
              },
            ),
          const SizedBox(height: 10),
          Text('Renews automatically at the same price until cancelled. Cancel any time from this page. Prices shown in USD.', style: VT.body(11, color: V.muted), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _planCard(VipPlan p) {
    final on = p == _plan;
    final perWeek = p.usd / (p.length.inDays / 7);
    return GestureDetector(
      onTap: () => setState(() => _plan = p),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
        decoration: BoxDecoration(
          color: on ? V.gold.withValues(alpha: 0.12) : V.surface,
          borderRadius: BorderRadius.circular(V.r),
          border: Border.all(color: on ? V.gold : V.line, width: on ? 1.5 : 1),
        ),
        child: Column(
          children: [
            if (p.savePercent > 0) Tag('Save ${p.savePercent}%', color: V.ok) else if (p.highlighted) const Tag('Popular', color: V.pink) else const SizedBox(height: 22),
            const SizedBox(height: 8),
            Text(p.label, style: VT.label(12)),
            const SizedBox(height: 4),
            Text(Fmt.usd(p.usd), style: VT.title(18)),
            Text('${Fmt.usd(perWeek)}/wk', style: VT.body(11, color: V.muted)),
          ],
        ),
      ),
    );
  }
}
